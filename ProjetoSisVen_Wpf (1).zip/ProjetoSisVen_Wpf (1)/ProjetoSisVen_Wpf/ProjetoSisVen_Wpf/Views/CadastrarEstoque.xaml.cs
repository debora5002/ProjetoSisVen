﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para CadastrarEstoque.xaml
    /// </summary>
    public partial class CadastrarEstoque : Window
    {

        private int _id;

        private Estoque _estoque;

        public CadastrarEstoque()
        {
            InitializeComponent();
            Loaded += CadastrarEstoque_Loaded;
        }

        public CadastrarEstoque(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarEstoque_Loaded;
        }

        private void CadastrarEstoque_Loaded(object sender, RoutedEventArgs e)
        {
            _estoque = new Estoque();

            // LoadComboBox();

            if (_id > 0)
                FillForm();

            CarregarDados();
        }

        private void CarregarDados()
        {
            try
            {
                var produtoDAO = new produtoDAO();
                CB_Produto.ItemsSource = produtoDAO.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            _estoque.Nome = Nome.Text;
            _estoque.Tipo = Tipo.Text;
            _estoque.Quantidade = int.Parse(Quantidade.Text);


            if (CB_Produto.SelectedItem != null)
            {
                _estoque.Produto = (Produto) CB_Produto.SelectedItem;
            }

            SaveData();
        }

        private bool Validate()
        {
            /*var validator = new estoqueValitador();
            var result = validator.Validate(_estoque);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new EstoqueDAO();
                    var text = "atualizado";

                    if (_estoque.Id == 0)
                    {
                        dao.Insert(_estoque);
                        text = "adicionado";
                    }
                    else
                        dao.Update(_estoque);

                    MessageBox.Show($"O Estoque foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new EstoqueDAO();
                _estoque = dao.GetById(_id);

                // Id.Text = _estoque.Id.ToString();
                Nome.Text = _estoque.Nome;
                Tipo.Text = _estoque.Tipo;
                Quantidade.Text = Convert.ToString(_estoque.Quantidade);
                CB_Produto.Text = Convert.ToString(_estoque.Produto);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_estoque.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando estoques?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            Nome.Text = "";
            Tipo.Text = "";
            Quantidade.Text = "";
            CB_Produto.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarEstoque consultarEstoque = new ConsultarEstoque();
            consultarEstoque.ShowDialog();

        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}