﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Helpers;
using DocumentFormat.OpenXml.Office2010.Excel;


namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para CadastrarEntrega.xaml
    /// </summary>
    public partial class CadastrarEntrega : Window
    {
        //private List<Funcionario> funcionarioList;

        private int _id;

        private Entrega _entrega;

        public CadastrarEntrega()
        {
            InitializeComponent();
            Loaded += CadastrarEntrega_Loaded;
        }

        public CadastrarEntrega(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarEntrega_Loaded;
        }

        private void CadastrarEntrega_Loaded(object sender, RoutedEventArgs e)
        {
            _entrega = new Entrega();

            //LoadComboBox();

            if (_id > 0)
                FillForm();

            CarregarDados();
        }

        private void CarregarDados()
        {
            try
            {
                var funcionarioDAO = new funcionarioDAO();
                CB_Funcionario.ItemsSource = funcionarioDAO.List();

                var ClienteDAO = new ClienteDAO();
                CB_Cliente.ItemsSource = ClienteDAO.List();

            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            _entrega.Endereco = Endereco.Text;
            _entrega.Telefone = Telefone.Text;

            if (CB_Cliente.SelectedItem != null)
            {
                _entrega.Cliente = (Cliente) CB_Cliente.SelectedItem;
            }

            if (CB_Funcionario.SelectedItem != null)
            {
                _entrega.Funcionario = (Funcionario) CB_Funcionario.SelectedItem;
            }

            SaveData();
        }

        private bool Validate()
        {
            /*var validator = new entregaValitador();
            var result = validator.Validate(_entrega);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new EntregaDAO();
                    var text = "atualizada";

                    if (_entrega.Id == 0)
                    {
                        dao.Insert(_entrega);
                        text = "adicionada";
                    }
                    else
                        dao.Update(_entrega);

                    MessageBox.Show($"A Entrega foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new EntregaDAO();
                _entrega = dao.GetById(_id);

                // Id.Text = _entrega.Id.ToString();
                Endereco.Text = _entrega.Endereco;
                Telefone.Text = _entrega.Telefone;
                CB_Cliente.Text = Convert.ToString(_entrega.Cliente);
                CB_Funcionario.Text = Convert.ToString(_entrega.Funcionario);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_entrega.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando entregas?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            Endereco.Text = "";
            Telefone.Text = "";
            CB_Cliente.Text = "";
            CB_Funcionario.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarEntrega consultarEntrega = new ConsultarEntrega();
            consultarEntrega.ShowDialog();

        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
