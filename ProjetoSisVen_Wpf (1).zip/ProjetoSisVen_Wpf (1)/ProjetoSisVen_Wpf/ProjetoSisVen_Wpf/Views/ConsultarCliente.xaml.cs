﻿using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.database;

namespace ProjetoSisVen_Wpf
{
    /// <summary>
    /// Lógica interna para ConsultarCliente.xaml
    /// </summary>
    public partial class ConsultarCliente : Window
    {
        public List<long> idsSelecionados = new List<long>();

        public ConsultarCliente()
        {
            InitializeComponent();
            Loaded += ConsultarCliente_Loaded;
        }

        private void ConsultarCliente_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDataGrid();
            CarregarBusca();
        }
        private void LoadDataGrid()
        {
            try
            {
                var dao = new ClienteDAO();

                dgvCliente.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MenuItem_Novo_Click(object sender, RoutedEventArgs e)
        {
            var window = new CadastrarCliente();
            window.ShowDialog();
            LoadDataGrid();
        }

        private void Button_Update_Click(object sender, RoutedEventArgs e)
        {
            var clienteSelected = dgvCliente.SelectedItem as Cliente;

            var window = new CadastrarCliente(clienteSelected.Id);
            window.ShowDialog();
            LoadDataGrid();
        }

        private void Button_Delete_Click(object sender, RoutedEventArgs e)
        {
            var clienteSelected = dgvCliente.SelectedItem as Cliente;

            var result = MessageBox.Show($"Deseja realmente remover o cliente `{clienteSelected.Nome}`?", "Confirmação de Exclusão",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);

            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    var dao = new ClienteDAO();
                    dao.Delete(clienteSelected);
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }


        private void CarregarBusca()
        {
            try
            {
                var dao = new ClienteDAO();

                dgvCliente.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
