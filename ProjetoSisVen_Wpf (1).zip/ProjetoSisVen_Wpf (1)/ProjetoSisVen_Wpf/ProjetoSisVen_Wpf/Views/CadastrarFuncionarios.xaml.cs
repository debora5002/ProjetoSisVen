﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.Views;
using ProjetoSisVen_Wpf.Helpers;
using System.IO;
using ProjetoSisVen_Wpf.database;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para CadastrarFuncionarios.xaml
    /// </summary>
    public partial class CadastrarFuncionarios : Window
    {
        private int _id;

        private Funcionario _funcionario;
        
        public CadastrarFuncionarios()
        {
            InitializeComponent();
            Loaded += CadastrarFuncionarios_Loaded;
        }

        public CadastrarFuncionarios(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarFuncionarios_Loaded;
        }

        private void CadastrarFuncionarios_Loaded(object sender, RoutedEventArgs e)
        {
            _funcionario = new Funcionario();

            //LoadComboBox();

            if (_id > 0)
                FillForm();
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            _funcionario.Nome = Nome.Text;
            _funcionario.Telefone = Telefone.Text;
            _funcionario.Cpf = CPF.Text;
            _funcionario.Rg = RG.Text;
            _funcionario.Endereco = Endereco.Text;
            _funcionario.Curriculo = Currículo.Text;          
            _funcionario.Cargo = Cargo.Text;

            if (double.TryParse(Salario.Text, out double salario))
                _funcionario.Salario = salario;

            SaveData();
        }

        private bool Validate()
        {
            /*var validator = new FuncionarioValitador();
            var result = validator.Validate(_funcionario);
            
            if(!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach(var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new funcionarioDAO();
                    var text = "atualizado";

                    if (_funcionario.Id == 0)
                    {
                        dao.Insert(_funcionario);
                        text = "adicionado";
                    }
                    else
                        dao.Update(_funcionario);

                    MessageBox.Show($"O Funcionário foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new funcionarioDAO();
                _funcionario = dao.GetById(_id);

                //Id.Text = _funcionario.Id.ToString();
                Nome.Text = _funcionario.Nome;
                Telefone.Text = _funcionario.Telefone;
                CPF.Text = _funcionario.Cpf;
                RG.Text = _funcionario.Rg; 
                Endereco.Text = _funcionario.Endereco;
                Currículo.Text = _funcionario.Curriculo;
                Cargo.Text = _funcionario.Cargo;
                Salario.Text = _funcionario.Salario.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_funcionario.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando funcionários?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            Nome.Text = "";
            Telefone.Text = "";
            CPF.Text = "";
            RG.Text = "";
            Endereco.Text = "";
            Currículo.Text = "";          
            Cargo.Text = "";
            Salario.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarFuncionario consultar = new ConsultarFuncionario();
            consultar.ShowDialog();
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

}
