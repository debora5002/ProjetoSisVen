﻿using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Views;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.database;

namespace ProjetoSisVen_Wpf
{
    /// <summary>
    /// Lógica interna para ConsultarEmpresa.xaml
    /// </summary>
    public partial class ConsultarEmpresa : Window
    {
        public ConsultarEmpresa()
        {
            InitializeComponent();
            Loaded += ConsultarEmpresa_Loaded;
        }
      
        private void ConsultarEmpresa_Loaded(object sender, RoutedEventArgs e)
        {
            CarregarBusca();
            LoadDataGrid();
        }

        private void LoadDataGrid()
        {
            try
            {
                var dao = new EmpresaDAO();

                dgvEmpresa.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void CarregarBusca()
        {
            try
                {
                var dao = new EmpresaDAO();

                dgvEmpresa.ItemsSource = dao.List();
                }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message , "Exceção" , MessageBoxButton.OK , MessageBoxImage.Error);
                
            }
        }

        private void Button_Update_Click(object sender, RoutedEventArgs e)
        {
            var empresaSelecionado = dgvEmpresa.SelectedItem as Empresa;

            var tela = new CadastrarEmpresa(empresaSelecionado.Id);
            tela.ShowDialog();
            LoadDataGrid();
        }

        private void Button_Delete_Click(object sender, RoutedEventArgs e)
        {
            var empresaSelected = dgvEmpresa.SelectedItem as Empresa;

            var result = MessageBox.Show($"Deseja realmente remover a empresa `{empresaSelected.Categoria}`?", "Confirmação de Exclusão",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);

            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    var dao = new EmpresaDAO();
                    dao.Delete(empresaSelected);
                    LoadDataGrid();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            
            }
        }
        private void MenuItem_Novo_Click(object sender, RoutedEventArgs e)
        {
            var window = new ConsultarEmpresa();
            window.ShowDialog();
            LoadDataGrid();
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
