﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Helpers;

namespace ProjetoSisVen_Wpf
{
    /// <summary>
    /// Lógica interna para CadastrarFornecedor.xaml
    /// </summary>
    public partial class CadastrarFornecedor : Window
    {
       //private Fornecedor _fornecedor = new Fornecedor();

        private int _id;

        private Fornecedor _fornecedor;
        public CadastrarFornecedor()
        {
            InitializeComponent();
            Loaded += CadastrarFornecedor_Loaded;
        }

        public CadastrarFornecedor(int id)
        {
            InitializeComponent();
            Loaded += CadastrarFornecedor_Loaded;

            _id = id;
        }

        private void CadastrarFornecedor_Loaded(object sender, RoutedEventArgs e)
        {
            _fornecedor = new Fornecedor();

            if (_id > 0)
                FillForm();

            

            //try
            //{

            //    if (_fornecedor.Id > 0)
            //    {
            //        var fornecedorDAO = new fornecedorDAO();
            //        _fornecedor = fornecedorDAO.GetById(_fornecedor.Id);

            //        //Id.Text = _fornecedor.Id.ToString();
            //        Nome.Text = _fornecedor.Nome;
            //        Nome_Fantasia.Text = _fornecedor.NomeFantasia;
            //        Razao_Social.Text = _fornecedor.RazaoSocial;
            //        Email.Text = _fornecedor.Email;
            //        Contato.Text = _fornecedor.Contato;
            //        Cnpj.Text = _fornecedor.Cnpj;
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Erro");
            //}
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            _fornecedor.Nome = Nome.Text;
            _fornecedor.NomeFantasia = Nome_Fantasia.Text;
            _fornecedor.RazaoSocial = Razao_Social.Text;
            _fornecedor.Email = Email.Text;
            _fornecedor.Contato = Contato.Text;
            _fornecedor.Cnpj = Cnpj.Text;

            SaveData();

            // Validação Verificar campos em branco

            //try
            //{
            //    var fornecedorDAO = new fornecedorDAO();

            //    if (_fornecedor.Id == 0)
            //    {
            //        fornecedorDAO.Insert(_fornecedor);

            //        MessageBox.Show($"Fornecedor `{_fornecedor.RazaoSocial}` adicionado com sucesso!");
            //    }
            //    else
            //    {
            //        fornecedorDAO.Update(_fornecedor);
            //        MessageBox.Show($"Fornecedor `{_fornecedor.RazaoSocial}` atualizado com sucesso!");
            //    }

            //   // this.Close();

            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
        }

        private bool Validate()
        {
            /*var validator = new fornecedorValitador();
            var result = validator.Validate(_fornecedor);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var tela = new fornecedorDAO();
                    var text = "atualizado";

                    if (_fornecedor.Id == 0)
                    {
                        tela.Insert(_fornecedor);
                        text = "adicionado";
                    }
                    else
                        tela.Update(_fornecedor);

                    MessageBox.Show($"O Fornecedor foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new fornecedorDAO();
                _fornecedor = dao.GetById(_id);

                //Id.Text = _fornecedor.Id.ToString();
                Nome.Text = _fornecedor.Nome;
                Nome_Fantasia.Text = _fornecedor.NomeFantasia;
                Razao_Social.Text = _fornecedor.RazaoSocial;
                Email.Text = _fornecedor.Email;
                Contato.Text = _fornecedor.Contato;
                Cnpj.Text = _fornecedor.Cnpj;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_fornecedor.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando fornecedores?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            Nome.Text = "";
            Nome_Fantasia.Text = "";
            Razao_Social.Text = "";
            Email.Text = "";
            Contato.Text = "";
            Cnpj.Text = "";
        }


        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarFornecedor consultarFornecedor = new ConsultarFornecedor();
            consultarFornecedor.ShowDialog();
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    } 
    
}
