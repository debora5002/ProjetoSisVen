﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para CadastrarCaixa.xaml
    /// </summary>
    public partial class CadastrarCaixa : Window
    {

        private int _id;

        private Caixa _caixa;

        public CadastrarCaixa()
        {
            InitializeComponent();
            Loaded += CadastrarCaixa_Loaded;
        }

        public CadastrarCaixa(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarCaixa_Loaded;
        }

        private void CadastrarCaixa_Loaded(object sender, RoutedEventArgs e)
        {
            _caixa = new Caixa();

            // LoadComboBox();

            if (_id > 0)
                FillForm();

            CarregarDados();
        }

        private void CarregarDados()
        {
            try
            {
                var funcionarioDAO = new funcionarioDAO();
                CB_Funcionario.ItemsSource = funcionarioDAO.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            _caixa.FormaRecPag = FormaRecPag.Text;
            _caixa.Status = Status.Text;
            _caixa.Numero = int.Parse(Numero.Text);
            _caixa.SaldoInicial = double.Parse(SaldoInicial.Text);
            _caixa.SaldoFinal = double.Parse(SaldoFinal.Text);


            if (CB_Funcionario.SelectedItem != null)
            {
                _caixa.Funcionario = CB_Funcionario.SelectedItem as Funcionario;
            }

            SaveData();
        }

        private bool Validate()
        {
            /*var validator = new caixaValitador();
            var result = validator.Validate(_caixa);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new CaixaDAO();
                    var text = "atualizado";

                    if (_caixa.Id == 0)
                    {
                        dao.Insert(_caixa);
                        text = "adicionado";
                    }
                    else
                        dao.Update(_caixa);

                    MessageBox.Show($"O Caixa foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new CaixaDAO();
                _caixa = dao.GetById(_id);

                // Id.Text = _caixa.Id.ToString();
                FormaRecPag.Text = _caixa.FormaRecPag;
                Status.Text = _caixa.Status;
                Numero.Text = Convert.ToString(_caixa.Numero);
                SaldoInicial.Text = Convert.ToString(_caixa.SaldoInicial);
                SaldoFinal.Text = Convert.ToString(_caixa.SaldoFinal);
                CB_Funcionario.Text = Convert.ToString(_caixa.Funcionario);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_caixa.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando caixas?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            FormaRecPag.Text = "";
            Status.Text = "";
            Numero.Text = "";
            SaldoInicial.Text = "";
            SaldoFinal.Text = "";
            CB_Funcionario.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarCaixa consultarCaixa = new ConsultarCaixa();
            consultarCaixa.ShowDialog();
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
