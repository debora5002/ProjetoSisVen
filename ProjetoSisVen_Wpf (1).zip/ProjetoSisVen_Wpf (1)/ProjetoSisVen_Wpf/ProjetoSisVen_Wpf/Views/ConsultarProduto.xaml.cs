﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Views;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.Helpers;

namespace ProjetoSisVen_Wpf
{
    /// <summary>
    /// Lógica interna para ConsultarProduto.xaml
    /// </summary>
    public partial class ConsultarProduto : Window
    {
        public ConsultarProduto()
        {
            InitializeComponent();
            Loaded += ConsultarProduto_Loaded;
        }

        
        private void ConsultarProduto_Loaded(object sender, RoutedEventArgs e)
        {
            CarregarBusca();
            LoadDataGrid();
        }

        private void LoadDataGrid()
        {
            try
            {
                var dao = new produtoDAO();

                dgvProduto.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CarregarBusca()
        {
            try
            {
                var dao = new produtoDAO();
                dgvProduto.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Update_Click(object sender, RoutedEventArgs e)
        {
            var produtoSelecionado = dgvProduto.SelectedItem as Produto;

            var tela = new CadastrarProduto(produtoSelecionado.Id);
            tela.ShowDialog();
            LoadDataGrid();
        }

        private void Button_Delete_Click(object sender, RoutedEventArgs e)
        {
            var produtoSelected = dgvProduto.SelectedItem as Produto;

            var result = MessageBox.Show($"Deseja realmente remover o produto `{produtoSelected.Nome}`?", "Confirmação de Exclusão",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);

            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    var dao = new produtoDAO();
                    dao.Delete(produtoSelected);
                    LoadDataGrid();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MenuItem_Novo_Click(object sender, RoutedEventArgs e)
        {
            var window = new ConsultarProduto();
            window.ShowDialog();
            LoadDataGrid();
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}

