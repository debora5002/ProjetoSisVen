﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para CadastrarDespesa.xaml
    /// </summary>
    public partial class CadastrarDespesa : Window
    {

        private int _id;

        private Despesa _despesa;

        public CadastrarDespesa()
        {
            InitializeComponent();
            Loaded += CadastrarDespesa_Loaded;
        }

        public CadastrarDespesa(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarDespesa_Loaded;
        }

        private void CadastrarDespesa_Loaded(object sender, RoutedEventArgs e)
        {
            _despesa = new Despesa();

            // LoadComboBox();

            if (_id > 0)
                FillForm();
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            _despesa.Tipo = Tipo.Text;
            _despesa.Descricao = Descricao.Text;
            _despesa.Forma_Pagamento = Forma_Pagamento.Text;
            _despesa.Valor = double.Parse(Valor.Text);
            _despesa.Status = Status.Text;

            if (dpDataVencimento.SelectedDate != null)
            {
                _despesa.DataVencimento = (DateTime)dpDataVencimento.SelectedDate;
            }


            SaveData();
        }

        private bool Validate()
        {
            /*var validator = new despesaValitador();
            var result = validator.Validate(_despesa);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new DespesaDAO();
                    var text = "atualizada";

                    if (_despesa.Id == 0)
                    {
                        dao.Insert(_despesa);
                        text = "adicionada";
                    }
                    else
                        dao.Update(_despesa);

                    MessageBox.Show($"A Despesa foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new DespesaDAO();
                _despesa = dao.GetById(_id);

                // Id.Text = _despesa.Id.ToString();
                Tipo.Text = _despesa.Tipo;
                Descricao.Text = _despesa.Descricao;
                Forma_Pagamento.Text = _despesa.Forma_Pagamento;
                Valor.Text = Convert.ToString(_despesa.Valor);
                Status.Text = _despesa.Status;
                dpDataVencimento.Text = Convert.ToString(_despesa.DataVencimento);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_despesa.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando despesas?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            Tipo.Text = "";
            Descricao.Text = "";
            Forma_Pagamento.Text = "";
            Valor.Text = "";
            Status.Text = "";
            dpDataVencimento.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarDespesa consultarDespesa = new ConsultarDespesa();
            consultarDespesa.ShowDialog();

        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}