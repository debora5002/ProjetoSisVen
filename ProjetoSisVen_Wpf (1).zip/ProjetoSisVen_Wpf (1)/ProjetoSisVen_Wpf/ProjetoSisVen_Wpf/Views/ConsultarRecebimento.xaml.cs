﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para ConsultarRecebimentoxaml.xaml
    /// </summary>
    public partial class ConsultarRecebimento : Window
    {

        public List<long> idsSelecionados = new List<long>();

        public ConsultarRecebimento()
        {
            InitializeComponent();
            Loaded += ConsultarRecebimento_Loaded;
        }

        private void ConsultarRecebimento_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDataGrid();
            CarregarBusca();
        }
        private void LoadDataGrid()
        {
            try
            {
                var dao = new RecebimentoDAO();

                dgvRecebimento.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MenuItem_Novo_Click(object sender, RoutedEventArgs e)
        {
            var window = new CadastrarRecebimento();
            window.ShowDialog();
            LoadDataGrid();
            CarregarBusca();
        }

        private void Button_Update_Click(object sender, RoutedEventArgs e)
        {
            var recebimentoSelected = dgvRecebimento.SelectedItem as Recebimento;

            var window = new CadastrarRecebimento(recebimentoSelected.Id);
            window.ShowDialog();
            LoadDataGrid();
            CarregarBusca();
        }

        private void Button_Delete_Click(object sender, RoutedEventArgs e)
        {
            var recebimentoSelected = dgvRecebimento.SelectedItem as Recebimento;

            var result = MessageBox.Show($"Deseja realmente remover o recebimento `{recebimentoSelected.Tipo}`?", "Confirmação de Exclusão",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);

            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    var dao = new RecebimentoDAO();
                    dao.Delete(recebimentoSelected);
                    LoadDataGrid();
                    CarregarBusca();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }


        private void CarregarBusca()
        {
            try
            {
                var dao = new RecebimentoDAO();

                dgvRecebimento.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}