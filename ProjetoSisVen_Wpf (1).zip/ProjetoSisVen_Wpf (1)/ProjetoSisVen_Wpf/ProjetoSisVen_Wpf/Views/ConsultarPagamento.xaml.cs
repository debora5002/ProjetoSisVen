﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para ConsultarPagamentoxaml.xaml
    /// </summary>
    public partial class ConsultarPagamento : Window
    {

        public List<long> idsSelecionados = new List<long>();

        public ConsultarPagamento()
        {
            InitializeComponent();
            Loaded += ConsultarPagamento_Loaded;
        }

        private void ConsultarPagamento_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDataGrid();
            CarregarBusca();
        }
        private void LoadDataGrid()
        {
            try
            {
                var dao = new PagamentoDAO();

                dgvPagamento.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MenuItem_Novo_Click(object sender, RoutedEventArgs e)
        {
            var window = new CadastrarPagamento();
            window.ShowDialog();
            LoadDataGrid();
        }

        private void Button_Update_Click(object sender, RoutedEventArgs e)
        {
            var pagamentoSelected = dgvPagamento.SelectedItem as Pagamento;

            var window = new CadastrarPagamento(pagamentoSelected.Id);
            window.ShowDialog();
            LoadDataGrid();
        }

        private void Button_Delete_Click(object sender, RoutedEventArgs e)
        {
            var pagamentoSelected = dgvPagamento.SelectedItem as Pagamento;

            var result = MessageBox.Show($"Deseja realmente remover o pagamento `{pagamentoSelected.Tipo}`?", "Confirmação de Exclusão",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);

            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    var dao = new PagamentoDAO();
                    dao.Delete(pagamentoSelected);
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }


        private void CarregarBusca()
        {
            try
            {
                var dao = new PagamentoDAO();

                dgvPagamento.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}