﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para CadastrarCompra.xaml
    /// </summary>
    public partial class CadastrarCompra : Window
    {

        private int _id;

        private Compra _compra;

        public CadastrarCompra()
        {
            InitializeComponent();
            Loaded += CadastrarCompra_Loaded;
        }

        public CadastrarCompra(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarCompra_Loaded;
        }

        private void CadastrarCompra_Loaded(object sender, RoutedEventArgs e)
        {
            _compra = new Compra();

            // LoadComboBox();

            if (_id > 0)
                FillForm();

            CarregarDados();
        }

        private void CarregarDados()
        {
            try
            {
                var funcionarioDAO = new funcionarioDAO();
                CB_Funcionario.ItemsSource = funcionarioDAO.List();

                var fornecedorDAO = new fornecedorDAO();
                CB_Fornecedor.ItemsSource = fornecedorDAO.List();

                var DespesaDAO = new DespesaDAO();
                CB_Despesa.ItemsSource = DespesaDAO.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            _compra.Nome = Nome.Text;
            _compra.Codigo_prod = Codigo.Text;
            _compra.Qtde_produto = int.Parse(Qtd_produto.Text);
            _compra.Valor_unitario = double.Parse(Valor_unitario.Text);
            _compra.Valor_total = double.Parse(Valor_total.Text);


            if (dpData.SelectedDate != null)
            {
                _compra.Data = (DateTime) dpData.SelectedDate;
            }

            if(CB_Fornecedor.SelectedItem != null)
            {
                _compra.Fornecedor = (Fornecedor) CB_Fornecedor.SelectedItem as Fornecedor;
            }

            if(CB_Funcionario.SelectedItem != null)
            {
                _compra.Funcionario = (Funcionario) CB_Funcionario.SelectedItem ;
            }

            if (CB_Despesa.SelectedItem != null)
            {
                _compra.Despesa = (Despesa) CB_Despesa.SelectedItem;
            }

            SaveData();
        }

        private bool Validate()
        {
            /*var validator = new compraValitador();
            var result = validator.Validate(_compra);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new CompraDAO();
                    var text = "atualizada";

                    if (_compra.Id == 0)
                    {
                        dao.Insert(_compra);
                        text = "adicionada";
                    }
                    else
                        dao.Update(_compra);

                    MessageBox.Show($"A Compra foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new CompraDAO();
                _compra = dao.GetById(_id);

                // Id.Text = _compra.Id.ToString();
                Nome.Text = _compra.Nome;
                Codigo.Text = _compra.Codigo_prod;
                Qtd_produto.Text = Convert.ToString(_compra.Qtde_produto);
                Valor_unitario.Text = Convert.ToString(_compra.Valor_unitario);
                Valor_total.Text = Convert.ToString(_compra.Valor_total);
                dpData.Text = Convert.ToString(_compra.Data);
                CB_Fornecedor.Text = Convert.ToString(_compra.Fornecedor);
                CB_Funcionario.Text = Convert.ToString(_compra.Funcionario);
                CB_Despesa.Text = Convert.ToString(_compra.Despesa);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_compra.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando compras?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            Nome.Text = "";
            Codigo.Text = "";
            Qtd_produto.Text = "";
            Valor_unitario.Text = "";
            Valor_total.Text = "";
            dpData.Text = "";
            CB_Fornecedor.Text = "";
            CB_Funcionario.Text = "";
            CB_Despesa.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarCompra consultarCompra = new ConsultarCompra();
            consultarCompra.ShowDialog();

        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
