﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para CadastrarCompra.xaml
    /// </summary>
    public partial class CadastrarVenda : Window
    {

        private int _id;

        private Venda _venda;

        public CadastrarVenda()
        {
            InitializeComponent();
            Loaded += CadastrarVenda_Loaded;
        }

        public CadastrarVenda(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarVenda_Loaded;
            CarregarDados();
            ListarProdutos();

        }

        private void CadastrarVenda_Loaded(object sender, RoutedEventArgs e)
        {
            //_venda = new Venda();

            //// LoadComboBox();

            //if (_id > 0)
            //    FillForm();

            CarregarDados();
        }

        private void CarregarDados()
        {
            try
            {
                var ClienteDAO = new ClienteDAO();
                CB_Cliente.ItemsSource = ClienteDAO.List();

                var funcionarioDAO = new funcionarioDAO();
                CB_Funcionario.ItemsSource = funcionarioDAO.List();

                var produtoDAO = new produtoDAO();
                CB_Produto.ItemsSource = produtoDAO.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            //_venda.Descricao = Descricao.Text;
            //_venda.Codigo = Codigo.Text;
            _venda.Quantidade = int.Parse(Quantidade.Text);
            //_venda.ValorUnitario = double.Parse(ValorUnitario.Tex);
            _venda.Forma_Recebimento = Forma_Recebimento.Text;
            _venda.ValorTotal = double.Parse(ValorTotal.Text);

            if (dpData.SelectedDate != null)
            {
                _venda.Data = (DateTime)dpData.SelectedDate;
            }

            if (CB_Cliente.SelectedItem != null)
            {
                _venda.Cliente = (Cliente)CB_Cliente.SelectedItem;
            }

            if (CB_Funcionario.SelectedItem != null)
            {
                _venda.Funcionario = (Funcionario)CB_Funcionario.SelectedItem;
            }


            if (CB_Produto.SelectedItem != null)
            {
                _venda.Produto = (Produto)CB_Produto.SelectedItem;
            }

            //SaveData();
        }

        private bool Validate()
        {
            /*var validator = new vendaValitador();
            var result = validator.Validate(_venda);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        //private void SaveData()
        //{
        //    try
        //    {
        //        if (Validate())
        //        {
        //            var dao = new VendaDAO();
        //            var text = "atualizada";

        //            if (_venda.Id == 0)
        //            {
        //                dao.Insert(_venda);
        //                text = "adicionada";
        //            }
        //            else
        //                dao.Update(_venda);

        //            MessageBox.Show($"A Venda foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
        //            CloseFormVerify();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
        //    }
        //}

        //private void FillForm()
        //{
        //    try
        //    {
        //        var dao = new VendaDAO();
        //        _venda = dao.GetById(_id);

        //        // Id.Text = _venda.Id.ToString();
        //        Descricao.Text = _venda.Descricao;
        //        Codigo.Text = _venda.Codigo;              
        //        Quantidade.Text = Convert.ToString(_venda.Quantidade);
        //        ValorUnitario.Text = Convert.ToString(_venda.ValorUnitario);
        //        Forma_Recebimento.Text = _venda.Forma_Recebimento;
        //        ValorTotal.Text = Convert.ToString(_venda.ValorTotal);
        //        dpData.Text = Convert.ToString(_venda.Data);
        //        CB_Cliente.Text = Convert.ToString(_venda.Cliente);
        //        CB_Funcionario.Text = Convert.ToString(_venda.Funcionario);
        //        CB_Entrega.Text = Convert.ToString(_venda.Entrega);
        //        CB_Produto.Text = Convert.ToString(_venda.Produto);
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
        //    }
        //}

        //private void CloseFormVerify()
        //{
        //    if (_venda.Id == 0)
        //    {
        //        var result = MessageBox.Show("Deseja continuar adicionando vendas?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

        //        if (result == MessageBoxResult.No)
        //            this.Close();
        //        else
        //            ClearInputs();
        //    }
        //    else
        //        this.Close();
        //}

        private void ClearInputs()
        {
            //Descricao.Text = "";
            //Codigo.Text = "";
            Quantidade.Text = "";
            //ValorUnitario.Text = "";
            Forma_Recebimento.Text = "";
            ValorTotal.Text = "";
            dpData.Text = "";
            CB_Cliente.Text = "";
            CB_Funcionario.Text = "";
          
            CB_Produto.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarVenda consultarVenda = new ConsultarVenda();
            consultarVenda.ShowDialog();

        }
        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
           
            Close();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var vendaSelected = dgvPro.SelectedItem as Venda;

            var result = MessageBox.Show($"Deseja realmente remover o pedido `{vendaSelected.Id}`?", "Confirmação de Exclusão",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);

            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    var dao = new VendaDAO();
                    dao.Delete(vendaSelected);

                    ListarProdutos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ListarProdutos()
        {
            var dao = new VendaDAO();
            dgvPro.ItemsSource = dao.List();
        }
        private void CalcularValorTotal()
        {
            if (CB_Produto.SelectedItem is Produto produto && int.TryParse(Quantidade.Text, out int quantidade))
            {
                double valorTotal = _venda.ValorTotal * quantidade;

                ValorTotal.Text = _venda.ValorTotal.ToString("C");
                ValorTotal.Text = valorTotal.ToString("C");
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("total: " + ValorTotal.Text);

            try
            {
                if (CB_Cliente.SelectedItem == null || CB_Funcionario.SelectedItem == null ||
                    CB_Produto.SelectedItem == null || string.IsNullOrEmpty(Quantidade.Text) ||
                    string.IsNullOrEmpty(ValorTotal.Text) ||
                    dpData.SelectedDate == null)
                {
                    MessageBox.Show("Por favor, preencha todos os campos antes de adicionar a venda.", "Campos Incompletos", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                else if (Convert.ToInt32(Quantidade.Text) <= 0)
                {
                    MessageBox.Show("Por favor, a quantidade não pode ser igual ou menor que zero.", "Quantidade Zero", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                double valorTotal = 0;

                if (CB_Produto.SelectedItem is Venda venda && int.TryParse(Quantidade.Text, out int quantidade)) valorTotal = _venda.ValorTotal * quantidade;

                Venda Venda = new Venda
                {
                    Data = (DateTime)dpData.SelectedDate,
                    Quantidade = Convert.ToInt32(Quantidade.Text),
                    ValorTotal = valorTotal,
                    Cliente = (Cliente)CB_Cliente.SelectedItem,
                    Forma_Recebimento = Forma_Recebimento.Text,
                    Funcionario = (Funcionario)CB_Funcionario.SelectedItem,
                    Produto = (Produto)CB_Produto.SelectedItem
                };

                VendaDAO VendaDAO = new VendaDAO();
                VendaDAO.Insert(_venda);
                //_context.SwitchScreen(new ListVenda(_context));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //private void Quantidadess(object sender, TextChangedEventArgs e)
        //{
        //    CalcularValorTotal();
        //}

        private void comboProduto(object sender, SelectionChangedEventArgs e)
        {
            CalcularValorTotal();
        }
    }
}
