﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para CadastrarRecebimento.xaml
    /// </summary>
    public partial class CadastrarRecebimento : Window
    {

        private int _id;

        private Recebimento _recebimento;

        public CadastrarRecebimento()
        {
            InitializeComponent();
            Loaded += CadastrarRecebimento_Loaded;
            
        }

        public CadastrarRecebimento(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarRecebimento_Loaded;
            
        }

        private void CadastrarRecebimento_Loaded(object sender, RoutedEventArgs e)
        {
            _recebimento = new Recebimento();


            if (_id > 0)
                FillForm();

            CarregarDados();
        }

        private void CarregarDados()
        {


            try
            {
                var VendaDAO = new VendaDAO();
                CB_Venda.ItemsSource = VendaDAO.List();

                var CaixaDAO = new CaixaDAO();
                CB_Caixa.ItemsSource = CaixaDAO.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            _recebimento.Tipo = Tipo.Text;
            _recebimento.Descricao = Descricao.Text;
            _recebimento.Forma_Recebimento = Forma_Recebimento.Text;
            _recebimento.Status = Status.Text;
            _recebimento.Valor = double.Parse(Valor.Text);

            if (dpDataRecebimento.SelectedDate != null)
            {
                _recebimento.DataRecebimento = (DateTime)dpDataRecebimento.SelectedDate;
            }

            if (dpDataVencimento.SelectedDate != null)
            {
                _recebimento.DataVencimento = (DateTime)dpDataVencimento.SelectedDate;
            }

            if (CB_Venda.SelectedItem != null)
            {
                _recebimento.Venda = (Venda) CB_Venda.SelectedItem;
            }

            if (CB_Caixa.SelectedItem != null)
            {
                _recebimento.Caixa = (Caixa) CB_Caixa.SelectedItem;
            }

            SaveData();
        }

        private bool Validate()
        {
            /*var validator = new recebimentoValitador();
            var result = validator.Validate(_recebimento);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new RecebimentoDAO();
                    var text = "atualizado";

                    if (_recebimento.Id == 0)
                    {
                        dao.Insert(_recebimento);
                        text = "adicionado";
                    }
                    else
                        dao.Update(_recebimento);

                    MessageBox.Show($"O Recebimento foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new RecebimentoDAO();
                _recebimento = dao.GetById(_id);

                // Id.Text = _recebimento.Id.ToString();
                Tipo.Text = _recebimento.Tipo;
                Descricao.Text = _recebimento.Descricao;
                Forma_Recebimento.Text = _recebimento.Forma_Recebimento;
                Status.Text = _recebimento.Status;
                Valor.Text = Convert.ToString(_recebimento.Valor);              
                dpDataRecebimento.Text = Convert.ToString(_recebimento.DataRecebimento);
                dpDataVencimento.Text = Convert.ToString(_recebimento.DataVencimento);               
                CB_Venda.Text = Convert.ToString(_recebimento.Venda);
                CB_Caixa.Text = Convert.ToString(_recebimento.Caixa);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_recebimento.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando recebimentos?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            Tipo.Text = "";
            Descricao.Text = "";
            Forma_Recebimento.Text = "";
            Status.Text = "";
            Valor.Text = "";         
            dpDataRecebimento.Text = "";
            dpDataVencimento.Text = "";           
            CB_Venda.Text = "";
            CB_Caixa.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarRecebimento consultarRecebimento = new ConsultarRecebimento();
            consultarRecebimento.ShowDialog();

        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}