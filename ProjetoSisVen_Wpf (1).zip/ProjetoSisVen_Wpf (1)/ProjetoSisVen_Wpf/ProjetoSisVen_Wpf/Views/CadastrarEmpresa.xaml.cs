﻿using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Views;
using ProjetoSisVen_Wpf.database;

namespace ProjetoSisVen_Wpf
{
    /// <summary>
    /// Lógica interna para CadastrarEmpresa.xaml
    /// </summary>
    public partial class CadastrarEmpresa : Window
    {
        private Empresa _empresa = new Empresa();
       
        private int _id;

        public CadastrarEmpresa()
        {
            InitializeComponent();
            Loaded += CadastrarEmpresa_Loaded;
        }

         public CadastrarEmpresa(int id)
        {
            InitializeComponent();
            Loaded += CadastrarEmpresa_Loaded;
            _empresa.Id = id;
        }

        private void CadastrarEmpresa_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {

                if (_empresa.Id > 0)
                {
                    var empresaDAO = new EmpresaDAO();
                    _empresa = empresaDAO.GetById(_empresa.Id);

                    //Id.Text = _empresa.Id.ToString();
                    txtCodigoDeBarras.Text = _empresa.Codigo_barras;
                    txtCategoria.Text = _empresa.Categoria;
                    txtTamanho.Text = _empresa.Tamanho;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro");
            }

            if (_id > 0)
                FillForm();
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {   
            _empresa.Codigo_barras = txtCodigoDeBarras.Text;
            _empresa.Categoria = txtCategoria.Text;
            _empresa.Tamanho = txtTamanho.Text;

            SaveData();
            
            // Validação Verificar campos em branco

            //try
            //{
            //    var empresaDAO = new EmpresaDAO();

            //    if (_empresa.Id == 0)
            //    {
            //        empresaDAO.Insert(_empresa);

            //        MessageBox.Show($"Empresa `{_empresa.Categoria}` adicionada com sucesso!");
            //    } 
            //    else
            //    {
            //        empresaDAO.Update(_empresa);
            //        MessageBox.Show($"Empresa `{_empresa.Categoria}` atualizada com sucesso!");
            //    }

            //    this.Close();

            //} catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);    
            //}
            
        }

        private bool Validate()
        {
            /*var validator = new empresaValitador();
            var result = validator.Validate(_empresa);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new EmpresaDAO();
                    var text = "atualizada";

                    if (_empresa.Id == 0)
                    {
                        dao.Insert(_empresa);
                        text = "adicionada";
                    }
                    else
                        dao.Update(_empresa);

                    MessageBox.Show($"A empresa foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btConsultar_Click_1(object sender, RoutedEventArgs e)
        {
            ConsultarEmpresa consultarEmpresa = new ConsultarEmpresa();
            consultarEmpresa.ShowDialog();
        }

        private void FillForm()
        {
            try
            {
                var dao = new EmpresaDAO();
                _empresa = dao.GetById(_id);

                // Id.Text = _empresa.Id.ToString();
                txtCodigoDeBarras.Text = _empresa.Codigo_barras;
                txtCategoria.Text = _empresa.Categoria;
                txtTamanho.Text = _empresa.Tamanho;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_empresa.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando empresas?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            txtCodigoDeBarras.Text = "";
            txtCategoria.Text = "";
            txtTamanho.Text = "";
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}