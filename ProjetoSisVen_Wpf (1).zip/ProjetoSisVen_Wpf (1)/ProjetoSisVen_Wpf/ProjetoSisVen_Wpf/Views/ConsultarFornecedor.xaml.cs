﻿using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Interfaces; 

namespace ProjetoSisVen_Wpf
{
    /// <summary>
    /// Lógica interna para ConsultarFornecedor.xaml
    /// </summary>
    public partial class ConsultarFornecedor : Window
    {
        public List<long> idsSelecionados = new List<long>();
        

        public ConsultarFornecedor()
        {
            InitializeComponent();
            Loaded += ConsultarFornecedor_Loaded;
        }

        private void ConsultarFornecedor_Loaded(object sender, RoutedEventArgs e)
        {
            CarregarBusca();
            LoadDataGrid();
        }

        private void LoadDataGrid()
        {
            try
            {
                var dao = new fornecedorDAO();

                dgvFornecedor.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CarregarBusca()
        {
            try
            {
                var dao = new fornecedorDAO();
                
                dgvFornecedor.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

      

        private void MenuItem_Novo_Click(object sender, RoutedEventArgs e)
        {
            var window = new ConsultarFornecedor();
            window.ShowDialog();
        }

        private void btEditar_Click(object sender, RoutedEventArgs e)
        {
            var fornecedorSelected = dgvFornecedor.SelectedItem as Fornecedor;

            var tela = new CadastrarFornecedor(fornecedorSelected.Id);
            tela.ShowDialog();
            LoadDataGrid();
        }

        private void btExcluir_Click(object sender, RoutedEventArgs e)
        {
            var fornecedorSelected = dgvFornecedor.SelectedItem as Fornecedor;

            var result = MessageBox.Show($"Deseja realmente remover o fornecedor `{fornecedorSelected.Nome}`?", "Confirmação de Exclusão",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);

            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    var dao = new fornecedorDAO();
                    dao.Delete(fornecedorSelected);
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}

