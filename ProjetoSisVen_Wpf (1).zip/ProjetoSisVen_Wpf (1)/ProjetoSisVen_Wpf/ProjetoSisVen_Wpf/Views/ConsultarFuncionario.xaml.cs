﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.Views;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para ConsultarFuncionario.xaml
    /// </summary>
    public partial class ConsultarFuncionario : Window
    {
        public ConsultarFuncionario()
        {
            InitializeComponent();
            Loaded += ConsultarFuncionario_Loaded;
        }

       

        private void ConsultarFuncionario_Loaded(object sender, RoutedEventArgs e)
        {
            
            CarregarBusca();
        }

        private void CarregarBusca()
        {
            try
            {
                var dao = new funcionarioDAO();

                dgvFuncionario.ItemsSource = dao.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //private void LoadDataGrid()
        //{
        //    try
        //    {
        //        var dao = new funcionarioDAO();

        //        dgvFuncionario.ItemsSource = dao.List();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
        //    }
        //}

        
        private void MenuItem_Novo_Click(object sender, RoutedEventArgs e)
        {
            var window = new CadastrarFuncionarios();
            window.ShowDialog();
            CarregarBusca();
        }

        private void Button_Update_Click(object sender, RoutedEventArgs e)
        {
            var funcionarioSelected = dgvFuncionario.SelectedItem as Funcionario;

            var window = new CadastrarFuncionarios(funcionarioSelected.Id);
            window.ShowDialog();
            CarregarBusca();
        }

        private void Button_Delete_Click(object sender, RoutedEventArgs e)
        {
            var funcionarioSelected = dgvFuncionario.SelectedItem as Funcionario;

            var result = MessageBox.Show($"Deseja realmente remover o funcionário `{funcionarioSelected.Nome}`?", "Confirmação de Exclusão",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);

            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    var dao = new funcionarioDAO();
                    dao.Delete(funcionarioSelected);
                    CarregarBusca();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
