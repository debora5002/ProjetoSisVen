﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;

namespace ProjetoSisVen_Wpf.Views
{
    /// <summary>
    /// Lógica interna para CadastrarPagamento.xaml
    /// </summary>
    public partial class CadastrarPagamento : Window
    {

        private int _id;

        private Pagamento _pagamento;

        public CadastrarPagamento()
        {
            InitializeComponent();
            Loaded += CadastrarPagamento_Loaded;
        }

        public CadastrarPagamento(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarPagamento_Loaded;
        }

        private void CadastrarPagamento_Loaded(object sender, RoutedEventArgs e)
        {
            _pagamento = new Pagamento();

            // LoadComboBox();

            if (_id > 0)
                FillForm();

            CarregarDados();
        }
        private void CarregarDados()
        {
            try
            {
                var DespesaDAO = new DespesaDAO();
                CB_Despesa.ItemsSource = DespesaDAO.List();

                var CaixaDAO = new CaixaDAO();
                CB_Caixa.ItemsSource = CaixaDAO.List();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            _pagamento.Tipo = Tipo.Text;
            _pagamento.Descricao = Descricao.Text;
            _pagamento.Forma_Pagamento = Forma_Pagamento.Text;
            _pagamento.Valor = double.Parse(Valor.Text);
            _pagamento.Status = Status.Text;

            if (dpDataVencimento.SelectedDate != null)
            {
                _pagamento.DataVencimento = (DateTime)dpDataVencimento.SelectedDate;
            }

            if (dpDataPagamento.SelectedDate != null)
            {
                _pagamento.DataPagamento = (DateTime)dpDataPagamento.SelectedDate;
            }

            if (CB_Despesa.SelectedItem != null)
            {
                _pagamento.Despesa = (Despesa) CB_Despesa.SelectedItem;
            }

            if (CB_Caixa.SelectedItem != null)
            {
                _pagamento.Caixa = (Caixa) CB_Caixa.SelectedItem;
            }

            SaveData();
        }

        private bool Validate()
        {
            /*var validator = new pagamentoValitador();
            var result = validator.Validate(_pagamento);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new PagamentoDAO();
                    var text = "atualizado";

                    if (_pagamento.Id == 0)
                    {
                        dao.Insert(_pagamento);
                        text = "adicionado";
                    }
                    else
                        dao.Update(_pagamento);

                    MessageBox.Show($"O Pagamento foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new PagamentoDAO();
                _pagamento = dao.GetById(_id);

                // Id.Text = _pagamento.Id.ToString();
                Tipo.Text = _pagamento.Tipo;
                Descricao.Text = _pagamento.Descricao;
                Forma_Pagamento.Text = _pagamento.Forma_Pagamento;                
                Valor.Text = Convert.ToString(_pagamento.Valor);
                Status.Text = _pagamento.Status;
                dpDataVencimento.Text = Convert.ToString(_pagamento.DataVencimento);
                dpDataPagamento.Text = Convert.ToString(_pagamento.DataPagamento);
                CB_Despesa.Text = Convert.ToString(_pagamento.Despesa);
                CB_Caixa.Text = Convert.ToString(_pagamento.Caixa);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_pagamento.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando pagamentos?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            Tipo.Text = "";
            Descricao.Text = "";
            Forma_Pagamento.Text = "";
            Valor.Text = "";
            Status.Text = "";
            dpDataVencimento.Text = "";
            dpDataPagamento.Text = "";
            CB_Despesa.Text = "";
            CB_Caixa.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarPagamento consultarPagamento = new ConsultarPagamento();
            consultarPagamento.ShowDialog();

        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}