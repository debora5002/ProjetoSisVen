﻿using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Views;

namespace ProjetoSisVen_Wpf
{
    /// <summary>
    /// Lógica interna para CadastrarProduto.xaml
    /// </summary>
    public partial class CadastrarProduto : Window
    {
        private int _id;
        private Produto _produto = new Produto();
        
        public CadastrarProduto()
        {
            InitializeComponent();
            Loaded += CadastrarProduto_Loaded;
        }

        public CadastrarProduto(int id)
        {
            InitializeComponent();
            Loaded += CadastrarProduto_Loaded;
            _id = id;
        }

        private void CadastrarProduto_Loaded(object sender, RoutedEventArgs e)
        {
            _produto = new Produto();

            if (_id > 0)
                FillForm();

            //try
            //{

            //    if (_produto.Id > 0)
            //    {
            //        var produtoDAO = new produtoDAO();
            //        _produto = produtoDAO.GetById(_produto.Id);

            //        //Id.Text = _produto.Id.ToString();
            //        txtNome.Text = _produto.Nome;
            //        txtTipoDeProduto.Text = _produto.Tipo_produto;
            //        txtClassificacao.Text = _produto.Classificação;
            //        txtValorUnitario1.Text = Convert.ToString(_produto.Valor_unitario);
            //        txtCor1.Text = _produto.Cor;
            //        txtTamanho1.Text = _produto.Tamanho;
            //        txtTipoDeTecido.Text = _produto.Tipo_tecido;
            //        txtCodigoDeBarras.Text = _produto.Codigo_barras;
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Erro");
            //}
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            _produto.Nome = txtNome.Text;
            _produto.Tipo_produto = txtTipoDeProduto.Text;
            _produto.Classificação = txtClassificacao.Text;
            _produto.Valor_unitario = Convert.ToDouble(txtValorUnitario1.Text);
            _produto.Cor = txtCor1.Text;
            _produto.Tamanho = txtTamanho1.Text;
            _produto.Tipo_tecido = txtTipoDeTecido.Text;
            _produto.Codigo_barras = txtCodigoDeBarras.Text;


            SaveData();
        }

        private bool Validate()
        {
            /*var validator = new produtoValitador();
            var result = validator.Validate(_produto);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new produtoDAO();
                    var text = "atualizado";

                    if (_produto.Id == 0)
                    {
                        dao.Insert(_produto);
                        text = "adicionado";
                    }
                    else
                        dao.Update(_produto);

                    MessageBox.Show($"O Produto foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new produtoDAO();
                _produto = dao.GetById(_id);

                // Id.Text = _produto.Id.ToString();
                txtNome.Text = _produto.Nome;
                txtTipoDeProduto.Text = _produto.Tipo_produto;
                txtClassificacao.Text = _produto.Classificação;
                txtValorUnitario1.Text = Convert.ToString(_produto.Valor_unitario);
                txtCor1.Text = _produto.Cor;
                txtTamanho1.Text = _produto.Tamanho;
                txtTipoDeTecido.Text = _produto.Tipo_tecido;
                txtCodigoDeBarras.Text = _produto.Codigo_barras;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_produto.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando produtos?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            txtNome.Text = "";
            txtTipoDeProduto.Text = "";
            txtClassificacao.Text = "";
            txtValorUnitario1.Text = "";
            txtCor1.Text = "";
            txtTamanho1.Text = "";
            txtTipoDeTecido.Text = "";
            txtCodigoDeBarras.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarProduto consultarProduto = new ConsultarProduto();
            consultarProduto.ShowDialog();
        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
