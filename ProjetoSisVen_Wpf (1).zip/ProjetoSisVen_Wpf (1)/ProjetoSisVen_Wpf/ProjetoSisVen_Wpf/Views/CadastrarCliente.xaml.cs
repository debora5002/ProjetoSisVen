﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.Views;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Helpers;
using DocumentFormat.OpenXml.Office2010.Excel;

namespace ProjetoSisVen_Wpf
{
    /// <summary>
    /// Lógica interna para CadastrarCliente.xaml
    /// </summary>
    public partial class CadastrarCliente : Window
    {
        private int _id;

        private Cliente _cliente;

        public CadastrarCliente()
        {
            InitializeComponent();
            Loaded += CadastrarCliente_Loaded;
        }

        public CadastrarCliente(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarCliente_Loaded;
        }

        private void CadastrarCliente_Loaded(object sender, RoutedEventArgs e)
        {
            _cliente = new Cliente();

           // LoadComboBox();

            if (_id > 0)
                FillForm();
        }

        private void btSalvar_Click(object sender , RoutedEventArgs e)
        {
            _cliente.Nome = Nome.Text;
            _cliente.Endereco = Endereco.Text;
            _cliente.Telefone = Telefone.Text;
            _cliente.Cpf = Cpf1.Text;

            SaveData();
        }

        private bool Validate()
        {
            /*var validator = new clienteValitador();
            var result = validator.Validate(_cliente);

            if (!result.IsValid)
            {
                string errors = null;
                var count = 1;

                foreach (var failure in result.Errors)
                {
                    errors += $"{count++} - {failure.ErrorMessage}\n";
                }

                MessageBox.Show(errors, "Validação de Dados", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            return result.IsValid;*/
            return true;
        }

        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new ClienteDAO();
                    var text = "atualizado";

                    if (_cliente.Id == 0)
                    {
                        dao.Insert(_cliente);
                        text = "adicionado";
                    }
                    else
                        dao.Update(_cliente);

                    MessageBox.Show($"O Cliente foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                    CloseFormVerify();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não Executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FillForm()
        {
            try
            {
                var dao = new ClienteDAO();
                _cliente = dao.GetById(_id);

               // Id.Text = _cliente.Id.ToString();
                Nome.Text = _cliente.Nome;
                Endereco.Text = _cliente.Endereco;
                Telefone.Text = _cliente.Telefone;
                Cpf1.Text = _cliente.Cpf;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseFormVerify()
        {
            if (_cliente.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando clientes?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }

        private void ClearInputs()
        {
            Nome.Text = "";
            Endereco.Text = "";
            Telefone.Text = "";
            Cpf1.Text = "";
        }

        private void btConsultar_Click(object sender, RoutedEventArgs e)
        {
            ConsultarCliente consultarCliente = new ConsultarCliente();
            consultarCliente.ShowDialog();

        }

        private void btVoltar_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}