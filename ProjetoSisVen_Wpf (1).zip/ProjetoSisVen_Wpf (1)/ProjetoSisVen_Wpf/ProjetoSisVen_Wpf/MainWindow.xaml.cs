﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.Views;


namespace ProjetoSisVen_Wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btCadastrarEmpresa(object sender, RoutedEventArgs e)
        {
            CadastrarEmpresa form = new CadastrarEmpresa();
            form.ShowDialog();
        }

        private void btCadastrarFuncionario(object sender, RoutedEventArgs e)
        {
            CadastrarFuncionarios form = new CadastrarFuncionarios();
            form.ShowDialog();
        }

        private void btCadastrarFornecedor(object sender, RoutedEventArgs e)
        {
            CadastrarFornecedor form = new CadastrarFornecedor();
            form.ShowDialog();

            var window = new MainWindow();
            window.ShowDialog();
        }

        private void btCadastrarCliente(object sender, RoutedEventArgs e)
        {
            CadastrarCliente form = new CadastrarCliente();
            form.ShowDialog();
        }

        private void btCadastrarProduto(object sender, RoutedEventArgs e)
        {
            CadastrarProduto form = new CadastrarProduto();
            form.ShowDialog();
        }

        private void btCadastrarCompra(object sender, RoutedEventArgs e)
        {
            CadastrarCompra form = new CadastrarCompra();
            form.ShowDialog();
        }

        private void btCadastrarCaixa(object sender, RoutedEventArgs e)
        {
            CadastrarCaixa form = new CadastrarCaixa();
            form.ShowDialog();
        }

        private void btCadastrarDespesa(object sender, RoutedEventArgs e)
        {
            CadastrarDespesa form = new CadastrarDespesa();
            form.ShowDialog();
        }

        private void btCadastrarEntrega(object sender, RoutedEventArgs e)
        {
            CadastrarEntrega form = new CadastrarEntrega();
            form.ShowDialog();
        }

        private void btCadastrarEstoque(object sender, RoutedEventArgs e)
        {
            CadastrarEstoque form = new CadastrarEstoque();
            form.ShowDialog();
        }

        private void btCadastrarPagamento(object sender, RoutedEventArgs e)
        {
            CadastrarPagamento form = new CadastrarPagamento();
            form.ShowDialog();
        }

        private void btCadastrarVenda(object sender, RoutedEventArgs e)
        {
            CadastrarVenda form = new CadastrarVenda();
            form.ShowDialog();
        }

        private void btCadastrarRecebimento(object sender, RoutedEventArgs e)
        {
            CadastrarRecebimento form = new CadastrarRecebimento();
            form.ShowDialog();
        }

   
    }
}
