﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoSisVen_Wpf.Models
{
    class Fornecedor
    {
        public int Id { get; set; }

        public string ? Nome { get; set; }

        public string ? NomeFantasia { get; set; }


        public string ? RazaoSocial { get; set; }

        
        public string ? Email { get; set; }

        public string ? Contato { get; set; }

        public string ? Cnpj { get; set;}
    }
}
