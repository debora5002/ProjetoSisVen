﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.Views;
using ProjetoSisVen_Wpf.Interfaces;

namespace ProjetoSisVen_Wpf.Models
{
    class EmpresaDAO : IDAO<Empresa>
    {
        private static Conexao conexao;

        public EmpresaDAO()
        {
            conexao = new Conexao();
        }

        public void Delete(Empresa t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "DELETE FROM empresa WHERE id_emp = @id";

                query.Parameters.AddWithValue("@id", t.Id);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexao.Close();
            }
        }

        public Empresa GetById(int id)
        {
             try
             {
                var query = conexao.Query();
                query.CommandText = "SELECT * FROM empresa WHERE id_emp = @codigo";

                query.Parameters.AddWithValue("@codigo", id);

                var resultado = query.ExecuteReader();

                var empresa = new Empresa();

                while (resultado.Read())
                {
                    empresa.Id = resultado.GetInt32("id_emp");
                    empresa.Codigo_barras = resultado.GetString("codigo_barras_emp");
                    empresa.Categoria = resultado.GetString("categoria_emp");
                    empresa.Tamanho = resultado.GetString("tamanho_emp");
                }

                return empresa;

             } catch (Exception ex)
             {
                throw ex;
             }
        }

        public void Insert(Empresa t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "INSERT INTO empresa (codigo_barras_emp, categoria_emp, tamanho_emp) " +
                    "VALUES (@codigobarras, @categoria, @tamanho)";

                query.Parameters.AddWithValue("@codigobarras", t.Codigo_barras);
                query.Parameters.AddWithValue("@categoria", t.Categoria);
                query.Parameters.AddWithValue("@tamanho", t.Tamanho);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Erro ao realizar o cadastro!");

            }
            catch (Exception )
            {
                throw;
            }
            finally
            {
                conexao.Close();
            }
        }
        public List<Empresa> List()
        {
            try
            {
                List<Empresa> list = new List<Empresa>();

                var query = conexao.Query();
                query.CommandText = "SELECT * FROM Empresa;";

                MySqlDataReader reader = query.ExecuteReader();

                while (reader.Read())
                {
                    list.Add(new Empresa()
                    {
                        Id = reader.GetInt32("id_emp") ,
                        Codigo_barras = DAOhelper.GetString(reader , "codigo_barras_emp") ,
                        Categoria = DAOhelper.GetString(reader , "categoria_emp") ,
                        Tamanho = DAOhelper.GetString(reader , "tamanho_emp") ,               
                    });
                }

                return list;
            }
            catch (Exception )
            {
                throw ;
            }
            finally
            {
                conexao.Close();
            }
            
        }

        public void Update(Empresa t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "UPDATE empresa SET codigo_barras_emp = @codigobarras, categoria_emp = @categoria, tamanho_emp = @tamanho WHERE id_emp = @codigo";

                query.Parameters.AddWithValue("@codigobarras", t.Codigo_barras);
                query.Parameters.AddWithValue("@categoria", t.Categoria);
                query.Parameters.AddWithValue("@tamanho", t.Tamanho);
                query.Parameters.AddWithValue("@codigo", t.Id);

                var resultado = query.ExecuteNonQuery();

                if (resultado == 0)
                {
                    throw new Exception("Registro não atualizado.");
                }

            } catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}