﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;
using System.Windows;

class RecebimentoDAO : IDAO<Recebimento>
{
    private static Conexao conexao;

    public RecebimentoDAO()
    {
        conexao = new Conexao();
    }

    public void Delete(Recebimento t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "DELETE FROM recebimento WHERE id_rec = @id";

            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Insert(Recebimento t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "INSERT INTO recebimento (tipo_rec, descricao_rec, forma_recebimento_rec, status_rec, valor_rec, data_recebimento_rec, data_vencimento_rec, id_ven_fk, id_cai_fk) " +
                "VALUES (@tipo, @descricao, @forma_recebimento, @status, @valor, @data_recebimento, @data_vencimento, @venda, @caixa)";

            query.Parameters.AddWithValue("@tipo", t.Tipo);
            query.Parameters.AddWithValue("@descricao", t.Descricao);
            query.Parameters.AddWithValue("@forma_recebimento", t.Forma_Recebimento);
            query.Parameters.AddWithValue("@status", t.Status);
            query.Parameters.AddWithValue("@valor", t.Valor);
            query.Parameters.AddWithValue("@data_recebimento", t.DataRecebimento);
            query.Parameters.AddWithValue("@data_vencimento", t.DataVencimento);
            query.Parameters.AddWithValue("@venda", t.Venda.Id);
            query.Parameters.AddWithValue("@caixa", t.Caixa.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Erro ao realizar o cadastro!");

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public Recebimento GetById(int id)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "SELECT * FROM recebimento " + "WHERE id_rec = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var recebimento = new Recebimento();

            while (reader.Read())
            {
                recebimento.Id = reader.GetInt32("id_rec");
                recebimento.Tipo = DAOhelper.GetString(reader, "tipo_rec");
                recebimento.Descricao = DAOhelper.GetString(reader, "descricao_rec");
                recebimento.Forma_Recebimento = DAOhelper.GetString(reader, "forma_recebimento_rec");
                recebimento.Status = DAOhelper.GetString(reader, "status_rec");
                recebimento.Valor = Convert.ToInt32(DAOhelper.GetString(reader, "valor_rec"));           
                recebimento.DataRecebimento = Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_recebimento_rec"));
                recebimento.DataVencimento = Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_vencimento_rec"));
                recebimento.Venda = new VendaDAO().GetById(reader.GetInt32("id_ven_fk"));
                recebimento.Caixa = new CaixaDAO().GetById(reader.GetInt32("id_cai_fk"));
            }

            return recebimento;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Query();
        }
    }

    private Recebimento ParseReader(MySqlDataReader dtReader)
    {
        throw new NotImplementedException();
    }

    public List<Recebimento> List()
    {
        try
        {
            List<Recebimento> list = new List<Recebimento>();

            var query = conexao.Query();
            query.CommandText = "SELECT * FROM recebimento;";

            MySqlDataReader reader = query.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Recebimento()
                {
                    Id = reader.GetInt32("id_rec"),
                    Tipo = DAOhelper.GetString(reader, "tipo_rec"),
                    Descricao = DAOhelper.GetString(reader, "descricao_rec"),
                    Forma_Recebimento = DAOhelper.GetString(reader, "forma_recebimento_rec"),
                    Status = DAOhelper.GetString(reader, "status_rec"),
                    Valor = Convert.ToInt32(DAOhelper.GetString(reader, "valor_rec")),
                    DataRecebimento = Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_recebimento_rec")),
                    DataVencimento = Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_vencimento_rec")),
                    Venda = new VendaDAO().GetById(reader.GetInt32("id_ven_fk")),
                    Caixa = new CaixaDAO().GetById(reader.GetInt32("id_cai_fk")),
                });
            }

            return list;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Update(Recebimento t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "UPDATE recebimento" +
                " SET tipo_rec = @tipo, descricao_rec = @descricao, forma_recebimento_rec = @forma_recebimento,  status_rec = @status, valor_rec = @valor, data_recebimento_rec = @data_recebimento, data_vencimento_rec = @data_vencimento, id_ven_fk = @venda, id_cai_fk = @caixa WHERE id_rec = @id";

            query.Parameters.AddWithValue("@tipo", t.Tipo);
            query.Parameters.AddWithValue("@descricao", t.Descricao);
            query.Parameters.AddWithValue("@forma_recebimento", t.Forma_Recebimento);
            query.Parameters.AddWithValue("@status", t.Status);
            query.Parameters.AddWithValue("@valor", t.Valor);
            query.Parameters.AddWithValue("@data_recebimento", t.DataRecebimento);
            query.Parameters.AddWithValue("@data_vencimento", t.DataVencimento);
            query.Parameters.AddWithValue("@venda", t.Venda.Id);
            query.Parameters.AddWithValue("@caixa", t.Caixa.Id);
            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Atualização do registro não foi realizada.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }
}