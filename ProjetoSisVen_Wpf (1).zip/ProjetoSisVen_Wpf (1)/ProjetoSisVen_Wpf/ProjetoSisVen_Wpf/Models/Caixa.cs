﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoSisVen_Wpf.Models
{
    internal class Caixa
    {
        public int Id { get; set; }

        public string? FormaRecPag { get; set; }

        public string ? Status { get; set; }

        public int Numero { get; set; }

        public double SaldoInicial { get; set; }

        public double SaldoFinal { get; set; }

        public Funcionario ? Funcionario { get; set; }
    }
}
