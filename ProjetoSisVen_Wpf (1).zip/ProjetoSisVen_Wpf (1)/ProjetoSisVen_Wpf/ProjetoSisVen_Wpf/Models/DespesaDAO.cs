﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;

class DespesaDAO : IDAO<Despesa>
{
    private static Conexao conexao;

    public DespesaDAO()
    {
        conexao = new Conexao();
    }

    public void Delete(Despesa t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "DELETE FROM despesa WHERE id_des = @id";

            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Insert(Despesa t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "INSERT INTO despesa (tipo_des, descricao_des, forma_pagamento_des, valor_des, status_des, data_vencimento_des) " +
                "VALUES (@tipo, @descricao, @forma_pagamento, @valor, @status, @data_vencimento)";

            query.Parameters.AddWithValue("@tipo", t.Tipo);
            query.Parameters.AddWithValue("@descricao", t.Descricao);
            query.Parameters.AddWithValue("@forma_pagamento", t.Forma_Pagamento);
            query.Parameters.AddWithValue("@valor", t.Valor);
            query.Parameters.AddWithValue("@status", t.Status);
            query.Parameters.AddWithValue("@data_vencimento", t.DataVencimento.ToString("yyyy-MM-dd"));

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Erro ao realizar o cadastro!");

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public Despesa GetById(int id)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "SELECT * FROM despesa " + "WHERE id_des = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var despesa = new Despesa();

            while (reader.Read())
            {
                despesa.Id = reader.GetInt32("id_des");
                despesa.Tipo = DAOhelper.GetString(reader, "tipo_des");
                despesa.Descricao = DAOhelper.GetString(reader, "descricao_des");
                despesa.Forma_Pagamento = DAOhelper.GetString(reader, "forma_pagamento_des");
                despesa.Valor = Convert.ToInt32(DAOhelper.GetString(reader, "valor_des"));
                despesa.Status = DAOhelper.GetString(reader, "status_des");
                despesa.DataVencimento = Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_vencimento_des"));
            }

            return despesa;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Query();
        }
    }

    private Despesa ParseReader(MySqlDataReader dtReader)
    {
        throw new NotImplementedException();
    }

    public List<Despesa> List()
    {
        try
        {
            List<Despesa> list = new List<Despesa>();

            var query = conexao.Query();
            query.CommandText = "SELECT * FROM despesa;";

            MySqlDataReader reader = query.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Despesa()
                {
                    Id = reader.GetInt32("id_des"),
                    Tipo = DAOhelper.GetString(reader, "tipo_des"),
                    Descricao = DAOhelper.GetString(reader, "descricao_des"),
                    Forma_Pagamento = DAOhelper.GetString(reader, "forma_pagamento_des"),
                    Valor = Convert.ToInt32(DAOhelper.GetString(reader, "valor_des")),
                    Status = DAOhelper.GetString(reader, "status_des"),
                    DataVencimento = Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_vencimento_des")),
                });
            }

            return list;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Update(Despesa t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "UPDATE despesa" +
                " SET tipo_des = @tipo, descricao_des = @descricao, forma_pagamento_des = @forma_pagamento, valor_des = @valor, status_des = @status, data_vencimento_des = @data_vencimento WHERE id_des = @id";

            query.Parameters.AddWithValue("@tipo", t.Tipo);
            query.Parameters.AddWithValue("@descricao", t.Descricao);
            query.Parameters.AddWithValue("@forma_pagamento", t.Forma_Pagamento);
            query.Parameters.AddWithValue("@valor", t.Valor);
            query.Parameters.AddWithValue("@status", t.Status);
            query.Parameters.AddWithValue("@data_vencimento", t.DataVencimento.ToString("yyyy-MM-dd"));
            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Atualização do registro não foi realizada.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }
}