﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;

class VendaDAO : IDAO<Venda>
{
    private static Conexao conexao;

    public VendaDAO()
    {
        conexao = new Conexao();
    }

    public void Delete(Venda t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "DELETE FROM venda WHERE id_ven = @id";

            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Insert(Venda t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "INSERT INTO venda ( data_ven, quantidade_ven, valor_unitario_ven, forma_recebimento_ven, id_func_fk, id_cli_fk) " +
                "VALUES ( @data, @quantidade, @valor_unitario, @forma_recebimento, @funcionario, @cliente)";

  
            query.Parameters.AddWithValue("@data", t.Data);
            query.Parameters.AddWithValue("@quantidade", t.Quantidade);
            query.Parameters.AddWithValue("@valor_unitario", t.ValorUnitario);
            query.Parameters.AddWithValue("@forma_recebimento", t.Forma_Recebimento);
                 
            query.Parameters.AddWithValue("@funcionario", t.Funcionario);
            query.Parameters.AddWithValue("@cliente", t.Cliente);
           
            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Erro ao realizar o cadastro!");

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public Venda GetById(int id)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "SELECT * FROM venda " + "WHERE id_ven = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var venda = new Venda();

            while (reader.Read())
            {
                venda.Id = reader.GetInt32("id_ven");
                //venda.Descricao = DAOhelper.GetString(reader, "descricao_ven");
                //venda.Codigo = DAOhelper.GetString(reader, "codigo_ven");
                venda.Data = Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_ven"));
                venda.Quantidade = Convert.ToInt32(DAOhelper.GetString(reader, "quantidade_ven"));
                venda.ValorUnitario = DAOhelper.GetDouble(reader, "valor_unitario_ven");
                venda.Forma_Recebimento = DAOhelper.GetString(reader, "forma_recebimento_ven");
                //venda.ValorTotal = DAOhelper.GetDouble(reader, "valor_total_ven");            
               // venda.Funcionario = new funcionarioDAO().GetById(reader.GetInt32("id_func_fk"));
                //venda.Cliente = new ClienteDAO().GetById(reader.GetInt32("id_cli_fk"));
                //venda.Entrega = new EntregaDAO().GetById(reader.GetInt32("id_entr_fk"));
            }

            return venda;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Query();
        }
    }

    private Venda ParseReader(MySqlDataReader dtReader)
    {
        throw new NotImplementedException();
    }

    public List<Venda> List()
    {
        try
        {
            List<Venda> list = new List<Venda>();

            var query = conexao.Query();
            query.CommandText = "SELECT * FROM venda;";

            MySqlDataReader reader = query.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Venda()
                {
                    Id = reader.GetInt32("id_ven"),
                    Quantidade = Convert.ToInt32(DAOhelper.GetString(reader, "quantidade_ven")),
                    ValorUnitario = DAOhelper.GetDouble(reader, "valor_unitario_ven"),
                    Forma_Recebimento = DAOhelper.GetString(reader, "forma_recebimento_ven"),
                    Data = Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_ven")),
                    Funcionario = new funcionarioDAO().GetById(reader.GetInt32("id_func_fk")),
                    Cliente = new ClienteDAO().GetById(reader.GetInt32("id_cli_fk")),
                });
            }

            return list;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Update(Venda t)
    {
        //try
        //{
        //    var query = conexao.Query();
        //    query.CommandText = "UPDATE venda" +
        //        " SET descricao_ven = @descricao, codigo_ven = @codigo, data_ven = @data, quantidade_ven = @quantidade, valor_unitario_ven = @valor_unitario, forma_recebimento_ven = @forma_recebimento, valor_total_ven = @valor_total, id_func_fk = @funcionario, id_cli_fk = @cliente, id_entr_fk = @entrega, id_prod_fk = @produto WHERE id_ven = @id";

        //    query.Parameters.AddWithValue("@descricao", t.Descricao);
        //    query.Parameters.AddWithValue("@codigo", t.Codigo);
        //    query.Parameters.AddWithValue("@data", t.Data);
        //    query.Parameters.AddWithValue("@quantidade", t.Quantidade);
        //    query.Parameters.AddWithValue("@valor_unitario", t.ValorUnitario);
        //    query.Parameters.AddWithValue("@forma_recebimento", t.Forma_Recebimento);
        //    query.Parameters.AddWithValue("@valor_total", t.ValorTotal);
        //    query.Parameters.AddWithValue("@cliente", t.Cliente);
        //    query.Parameters.AddWithValue("@funcionario", t.Funcionario);
        //    query.Parameters.AddWithValue("@entrega", t.Entrega);
        //    query.Parameters.AddWithValue("@produto", t.Produto);
        //    query.Parameters.AddWithValue("@id", t.Id);

        //    var result = query.ExecuteNonQuery();

        //    if (result == 0)
        //        throw new Exception("Atualização do registro não foi realizada.");

        //}
        //catch (Exception e)
        //{
        //    throw e;
        //}
        //finally
        //{
        //    conexao.Close();
        //}
    }
}