﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoSisVen_Wpf.Models
{
    internal class Venda
    {
        public int Id { get; set; }

        public string ? Descricao { get; set; }

        public string ? Codigo { get; set; }

        public DateTime Data { get; set; }

        public int Quantidade { get; set; }

        public double ValorUnitario { get; set; }

        public string? Forma_Recebimento { get; set; }

        public Double ValorTotal { get; set; }

        public Cliente ? Cliente { get; set; }

        public Funcionario ? Funcionario { get; set; }

        public Entrega ? Entrega { get; set; }

        public Produto ? Produto { get; set; }
    }
}
