﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;

class ClienteDAO : IDAO<Cliente>
{
    private static Conexao conexao;

    public ClienteDAO()
    {
        conexao = new Conexao();
    }

    public void Delete(Cliente t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "DELETE FROM cliente WHERE id_cli = @id";

            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Insert(Cliente t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "INSERT INTO cliente (nome_cli,  endereco_cli, telefone_cli, cpf_cli) " +
                "VALUES (@nome, @endereco, @telefone, @cpf)";

            query.Parameters.AddWithValue("@nome", t.Nome);
            query.Parameters.AddWithValue("@endereco", t.Endereco);
            query.Parameters.AddWithValue("@telefone", t.Telefone);
            query.Parameters.AddWithValue("@cpf", t.Cpf);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Erro ao realizar o cadastro!");

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public Cliente GetById(int id)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "SELECT * FROM cliente " + "WHERE id_cli = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var cliente = new Cliente();

            while (reader.Read())
            {
                cliente.Id = reader.GetInt32("id_cli");
                cliente.Nome = DAOhelper.GetString(reader, "nome_cli");
                cliente.Endereco = DAOhelper.GetString(reader, "endereco_cli");
                cliente.Telefone = DAOhelper.GetString(reader, "telefone_cli");
                cliente.Cpf = DAOhelper.GetString(reader, "cpf_cli");
            }

            return cliente;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Query();
        }
    }

    private Cliente ParseReader(MySqlDataReader dtReader)
    {
        throw new NotImplementedException();
    }

    public List<Cliente> List()
    {
        try
        {
            List<Cliente> list = new List<Cliente>();

            var query = conexao.Query();
            query.CommandText = "SELECT * FROM cliente;";

            MySqlDataReader reader = query.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Cliente()
                {
                    Id = reader.GetInt32("id_cli"),
                    Nome = DAOhelper.GetString(reader, "nome_cli"),
                    Endereco = DAOhelper.GetString(reader, "endereco_cli"),
                    Telefone = DAOhelper.GetString(reader, "telefone_cli"),
                    Cpf = DAOhelper.GetString(reader, "cpf_cli")
                });
            }

            return list;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Update(Cliente t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "UPDATE cliente" +
                " SET nome_cli = @nome, endereco_cli = @endereco, telefone_cli = @telefone, cpf_cli = @cpf WHERE id_cli = @id";

            query.Parameters.AddWithValue("@nome", t.Nome);
            query.Parameters.AddWithValue("@endereco", t.Endereco);
            query.Parameters.AddWithValue("@telefone", t.Telefone);
            query.Parameters.AddWithValue("@cpf", t.Cpf);
            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Atualização do registro não foi realizada.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }
}
