﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;

class VendaProdutoDAO : IDAO<VendaProduto>
{
    private static Conexao conexao;

    public VendaProdutoDAO()
    {
        conexao = new Conexao();
    }

    public void Delete(VendaProduto t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "DELETE FROM venda_produto WHERE id_ven_prod = @id";

            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Insert(VendaProduto t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "INSERT INTO venda_produto (quantidade_ven_prod, valorTotal_ven_prod, valor_ven_prod, id_ven_fk, id_prod_fk) " +
                "VALUES (@quantidade, @valorTotal, @valor, @produto, @venda)";

            query.Parameters.AddWithValue("@quantidade", t.Quantidade);
            query.Parameters.AddWithValue("@valorTotal", t.ValorTotal);
            query.Parameters.AddWithValue("@valor", t.Valor);
            
            query.Parameters.AddWithValue("@produto", t.Produto.Id);
    
            query.Parameters.AddWithValue("@venda", t.Venda.Id);
         

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Erro ao realizar o cadastro!");

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public VendaProduto GetById(int id)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "SELECT * FROM venda_produto " + "WHERE id_ven_prod = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var venda_produto = new VendaProduto();

            while (reader.Read())
            {
                venda_produto.Id = reader.GetInt32("id_ven_prod");
                venda_produto.Quantidade = DAOhelper.GetString(reader, "quantidade_ven_prod");
                venda_produto.Valor = Convert.ToInt32(DAOhelper.GetString(reader, "valor_ven_prod"));
                venda_produto.ValorTotal = Convert.ToInt32(DAOhelper.GetString(reader, "valorTotal_ven_prod"));
                venda_produto.Venda = new VendaDAO().GetById(reader.GetInt32("id_ven_fk"));
                venda_produto.Produto = new produtoDAO().GetById(reader.GetInt32("id_prod_fk"));
            }

            return venda_produto;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Query();
        }
    }

    private VendaProduto ParseReader(MySqlDataReader dtReader)
    {
        throw new NotImplementedException();
    }

    public List<VendaProduto> List()
    {
        try
        {
            List<VendaProduto> list = new List<VendaProduto>();

            var query = conexao.Query();
            query.CommandText = "SELECT * FROM venda_produto;";

            MySqlDataReader reader = query.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new VendaProduto()
                {
                    Id = reader.GetInt32("id_rec"),
                    Quantidade = DAOhelper.GetString(reader, "quantidade_ven_prod"),
                    Valor = Convert.ToInt32(DAOhelper.GetString(reader, "valor_ven_prod")),
                    ValorTotal = Convert.ToInt32(DAOhelper.GetString(reader, "valorTotal_ven_prod")),
                    Venda = new VendaDAO().GetById(reader.GetInt32("id_ven_fk")),
                    Produto = new produtoDAO().GetById(reader.GetInt32("id_prod_fk")),
                });
            }

            return list;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Update(VendaProduto t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "UPDATE venda_produto" +
                " SET quantidade_ven_prod = @quantidade, valor_ven_prod = @valor, valorTotal_ven_prod = @valorTotal, id_ven_fk = @venda, id_prod_fk = @produto WHERE id_ven_prod = @id";

            query.Parameters.AddWithValue("@quantidade", t.Quantidade);
            query.Parameters.AddWithValue("@valor", t.Valor);
            query.Parameters.AddWithValue("@valorTotal", t.ValorTotal);
            query.Parameters.AddWithValue("@venda", t.Venda.Id);
            query.Parameters.AddWithValue("@produto", t.Produto.Id);
            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Atualização do registro não foi realizada.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }
}