﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;

class CaixaDAO : IDAO<Caixa>
{
    private static Conexao conexao;

    public CaixaDAO()
    {
        conexao = new Conexao();
    }

    public void Delete(Caixa t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "DELETE FROM caixa WHERE id_cai = @id";

            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Insert(Caixa t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "INSERT INTO caixa (forma_rec_pag_cai, status_cai, numero_cai, saldo_inicial_cai, saldo_final_cai, id_func_fk) " +
                "VALUES (@forma_rec_pag, @status, @numero, @saldo_inicial, @saldo_final, @funcionario)";

            query.Parameters.AddWithValue("@forma_rec_pag", t.FormaRecPag);
            query.Parameters.AddWithValue("@status", t.Status);
            query.Parameters.AddWithValue("@numero", t.Numero);
            query.Parameters.AddWithValue("@saldo_inicial", t.SaldoInicial);
            query.Parameters.AddWithValue("@saldo_final", t.SaldoFinal);
            query.Parameters.AddWithValue("@funcionario", t.Funcionario.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Erro ao realizar o cadastro!");

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public Caixa GetById(int id)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "SELECT * FROM caixa " + "WHERE id_cai = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var caixa = new Caixa();

            while (reader.Read())
            {
                caixa.Id = reader.GetInt32("id_cai");
                caixa.FormaRecPag = DAOhelper.GetString(reader, "forma_rec_pag_cai");
                caixa.Status = DAOhelper.GetString(reader, "status_cai");
                caixa.Numero = Convert.ToInt32(DAOhelper.GetString(reader, "numero_cai"));
                caixa.SaldoInicial = DAOhelper.GetDouble(reader, "saldo_inicial_cai");
                caixa.SaldoFinal = DAOhelper.GetDouble(reader, "saldo_final_cai");
                caixa.Funcionario = new funcionarioDAO().GetById(reader.GetInt32("id_func_fk"));
            }

            return caixa;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Query();
        }
    }

    private Caixa ParseReader(MySqlDataReader dtReader)
    {
        throw new NotImplementedException();
    }

    public List<Caixa> List()
    {
        try
        {
            List<Caixa> list = new List<Caixa>();

            var query = conexao.Query();
            query.CommandText = "SELECT * FROM caixa;";

            MySqlDataReader reader = query.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Caixa()
                {
                    Id = reader.GetInt32("id_cai"),
                    FormaRecPag = DAOhelper.GetString(reader, "forma_rec_pag_cai"),
                    Status = DAOhelper.GetString(reader, "status_cai"),
                    Numero = Convert.ToInt32(DAOhelper.GetString(reader, "numero_cai")),
                    SaldoInicial = DAOhelper.GetDouble(reader, "saldo_inicial_cai"),
                    SaldoFinal = DAOhelper.GetDouble(reader, "saldo_final_cai"),
                    Funcionario = new funcionarioDAO().GetById(reader.GetInt32("id_func_fk")),
                });
            }

            return list;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Update(Caixa t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "UPDATE caixa" +
                " SET forma_rec_pag_cai = @forma_rec_pag, status_cai = @status, numero_cai = @numero, saldo_inicial_cai = @saldo_inicial, saldo_final_cai = @saldo_final, id_func_fk = @funcionario WHERE id_cai = @id";

            query.Parameters.AddWithValue("@forma_rec_pag", t.FormaRecPag);
            query.Parameters.AddWithValue("@status", t.Status);
            query.Parameters.AddWithValue("@numero", t.Numero);
            query.Parameters.AddWithValue("@saldo_inicial", t.SaldoInicial);
            query.Parameters.AddWithValue("@saldo_final", t.SaldoFinal);
            query.Parameters.AddWithValue("@funcionario", t.Funcionario);
            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Atualização do registro não foi realizada.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }
}