﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoSisVen_Wpf.Models
{
    internal class Entrega
    {
        public int Id { get; set; }

        public string ? Endereco { get; set; }

        public string ? Telefone { get; set; }

        public Cliente ? Cliente { get; set; }

        public Funcionario ? Funcionario { get; set; }
    }
}
