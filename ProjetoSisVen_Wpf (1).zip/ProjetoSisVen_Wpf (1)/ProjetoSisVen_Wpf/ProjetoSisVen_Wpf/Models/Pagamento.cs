﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoSisVen_Wpf.Models
{
    internal class Pagamento
    {
        public int Id { get; set; }

        public string ? Tipo { get; set; }

        public string? Descricao { get; set; }

        public string ? Forma_Pagamento { get; set; }

        public double Valor { get; set; }

        public string ? Status { get; set; }

        public DateTime DataVencimento { get; set; }

        public DateTime DataPagamento { get; set; }

        public Despesa ? Despesa { get; set; }
        
        public Caixa ? Caixa { get; set; }
    }
}
