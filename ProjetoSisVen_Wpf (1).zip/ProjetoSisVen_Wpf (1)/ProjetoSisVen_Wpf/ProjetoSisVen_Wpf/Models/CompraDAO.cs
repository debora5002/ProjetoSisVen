﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;

class CompraDAO : IDAO<Compra>
{
    private static Conexao conexao;

    public CompraDAO()
    {
        conexao = new Conexao();
    }

    public void Delete(Compra t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "DELETE FROM compra WHERE id_com = @id";

            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Insert(Compra t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "INSERT INTO compra (nome_com, codigo_prod_com, quantidade_prod_com, valor_unitario_com, valor_total_com, data_com, id_for_fk, id_func_fk, id_des_fk) " +
                "VALUES (@nome_prod, @codigo_prod, @quantidade_prod, @valor_unitario, @valor_total, @data, @fornecedor, @funcionario, @despesa)";

            query.Parameters.AddWithValue("@nome_prod", t.Nome);
            query.Parameters.AddWithValue("@codigo_prod", t.Codigo_prod);
            query.Parameters.AddWithValue("@quantidade_prod", t.Qtde_produto);
            query.Parameters.AddWithValue("@valor_unitario", t.Valor_unitario);
            query.Parameters.AddWithValue("@valor_total", t.Valor_total);
            query.Parameters.AddWithValue("@data", t.Data.ToString("yyyy-MM-dd"));
            query.Parameters.AddWithValue("@fornecedor", t.Fornecedor.Id);
            query.Parameters.AddWithValue("@funcionario", t.Funcionario.Id);
            query.Parameters.AddWithValue("@despesa", t.Despesa.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Erro ao realizar o cadastro!");

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public Compra GetById(int id)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "SELECT * FROM compra " + "WHERE id_com = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var compra = new Compra();

            while (reader.Read())
            {
                compra.Id = reader.GetInt32("id_com");
                compra.Nome = reader.GetString("nome_com");
                compra.Codigo_prod = reader.GetString("codigo_prod_com");
                compra.Qtde_produto = reader.GetInt32("quantidade_prod_com");
                compra.Valor_unitario = reader.GetDouble("valor_unitario_com");
                compra.Valor_total = reader.GetDouble("valor_total_com");
                compra.Data = (DateTime) reader.GetDateTime("data_com");
                compra.Fornecedor = new fornecedorDAO().GetById(reader.GetInt32("id_for_fk"));
                compra.Funcionario = new funcionarioDAO().GetById(reader.GetInt32("id_func_fk"));
                compra.Despesa = new DespesaDAO().GetById(reader.GetInt32("id_des_fk"));
            }

            return compra;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Query();
        }
    }

    private Compra ParseReader(MySqlDataReader dtReader)
    {
        throw new NotImplementedException();
    }

    public List<Compra> List()
    {
        try
        {
            List<Compra> list = new List<Compra>();

            var query = conexao.Query();
            query.CommandText = "SELECT * FROM compra;";

            MySqlDataReader reader = query.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Compra()
                {
                    Id = reader.GetInt32("id_com"),
                    Nome = DAOhelper.GetString(reader, "nome_com"),
                    Codigo_prod = DAOhelper.GetString(reader, "codigo_prod_com"),
                    Qtde_produto = Convert.ToInt32(DAOhelper.GetString(reader, "quantidade_prod_com")),
                    Valor_unitario = DAOhelper.GetDouble(reader, "valor_unitario_com"),
                    Valor_total = DAOhelper.GetDouble(reader, "valor_total_com"),
                    Data = (DateTime)Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_com")),
                    Fornecedor =  new fornecedorDAO().GetById(reader.GetInt32("id_for_fk")),
                    Funcionario = new funcionarioDAO().GetById(reader.GetInt32("id_func_fk")),
                    Despesa = new DespesaDAO().GetById(reader.GetInt32("id_des_fk")),
                });
            }

            return list;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Update(Compra t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "UPDATE compra" +
                " SET nome_com = @nome_prod, codigo_prod_com = @codigo_prod, quantidade_prod_com = @quantidade_prod, valor_unitario_com = @valor_unitario, valor_total_com = @valor_total, data_com = @data, id_for_fk = @fornecedor, id_func_fk = @funcionario, id_des_fk = @despesa WHERE id_com = @id";

            query.Parameters.AddWithValue("@nome_prod", t.Nome);
            query.Parameters.AddWithValue("@codigo_prod", t.Codigo_prod);
            query.Parameters.AddWithValue("@quantidade_prod", t.Qtde_produto);
            query.Parameters.AddWithValue("@valor_unitario", t.Valor_unitario);
            query.Parameters.AddWithValue("@valor_total", t.Valor_total);
            query.Parameters.AddWithValue("@data", t.Data);
            query.Parameters.AddWithValue("@fornecedor", t.Fornecedor);
            query.Parameters.AddWithValue("@funcionario", t.Funcionario);
            query.Parameters.AddWithValue("@despesa", t.Despesa);
            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Atualização do registro não foi realizada.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }
}

