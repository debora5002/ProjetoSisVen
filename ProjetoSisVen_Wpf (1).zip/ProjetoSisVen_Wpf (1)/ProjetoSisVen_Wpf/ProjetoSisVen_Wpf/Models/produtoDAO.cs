﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.Views;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;

namespace ProjetoSisVen_Wpf.Models
{
    class produtoDAO : IDAO<Produto>
    {
        private static Conexao conexao;

        public produtoDAO()
        {
            conexao = new Conexao();
        }

        public void Delete(Produto t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "DELETE FROM produto WHERE id_prod = @id";

                query.Parameters.AddWithValue("@id", t.Id);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexao.Close();
            }
        }

        public Produto GetById(int id)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "SELECT * FROM produto WHERE id_prod = @codigo";

                query.Parameters.AddWithValue("@codigo", id);

                var resultado = query.ExecuteReader();

                var produto = new Produto();

                while (resultado.Read())
                {
                    produto.Id = resultado.GetInt32("id_prod");
                    produto.Nome = DAOhelper.GetString(resultado, "nome_prod");
                    produto.Tipo_produto = DAOhelper.GetString(resultado, "tipo_prod");
                    produto.Valor_unitario = DAOhelper.GetDouble(resultado, "valor_prod");
                    produto.Tamanho = DAOhelper.GetString(resultado, "tamanho_prod");
                    produto.Cor = DAOhelper.GetString(resultado, "cor_prod");
                    produto.Classificação = DAOhelper.GetString(resultado, "classificacao_prod");
                    produto.Tipo_tecido = DAOhelper.GetString(resultado, "tipo_tecido_prod");
                    produto.Codigo_barras = DAOhelper.GetString(resultado, "codigo_barras_prod");
                }

                return produto;

            } catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Insert(Produto t)
        {
            try
            {
                var query = conexao.Query();

                query.CommandText = "INSERT INTO Produto " +
                    "(nome_prod, tipo_prod, valor_prod, tamanho_prod, cor_prod, classificacao_prod, tipo_tecido_prod, codigo_barras_prod) " +
                    "VALUES (@nome, @tipo, @valor, @tamanho, @cor, @classificacao, @tipotecido, @codigobarras)";

                query.Parameters.AddWithValue("@nome", t.Nome);
                query.Parameters.AddWithValue("@tipo", t.Tipo_produto);
                query.Parameters.AddWithValue("@valor", t.Valor_unitario);
                query.Parameters.AddWithValue("@tamanho", t.Tamanho);
                query.Parameters.AddWithValue("@cor", t.Cor);
                query.Parameters.AddWithValue("@classificacao", t.Classificação);
                query.Parameters.AddWithValue("@tipotecido", t.Tipo_tecido);
                query.Parameters.AddWithValue("@codigobarras", t.Codigo_barras);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Erro ao realizar o cadastro!");

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void Update(Produto t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "UPDATE produto SET nome_prod = @nome, tipo_prod = @tipo, valor_prod = @valor, " +
                    "tamanho_prod = @tamanho, cor_prod = @cor, classificacao_prod = @classificacao, tipo_tecido_prod = @tipotecido, codigo_barras_prod = @codigobarras  WHERE id_prod = @codigo";

                query.Parameters.AddWithValue("@nome", t.Nome);
                query.Parameters.AddWithValue("@tipo", t.Tipo_produto);
                query.Parameters.AddWithValue("@valor", t.Valor_unitario);
                query.Parameters.AddWithValue("@tamanho", t.Tamanho);
                query.Parameters.AddWithValue("@cor", t.Cor);
                query.Parameters.AddWithValue("@classificacao", t.Classificação);
                query.Parameters.AddWithValue("@tipotecido", t.Tipo_tecido);
                query.Parameters.AddWithValue("@codigobarras", t.Codigo_barras);
                query.Parameters.AddWithValue("@codigo", t.Id);

                var resultado = query.ExecuteNonQuery();

                if (resultado == 0)
                {
                    throw new Exception("Registro não atualizado.");
                }

            } catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Produto> List()
        {
            try
            {
                List<Produto> list = new List<Produto>();

                var query = conexao.Query();
                query.CommandText = "SELECT * FROM Produto;";

                MySqlDataReader reader = query.ExecuteReader();

                while (reader.Read())
                {
                    list.Add(new Produto()
                    {
                        Id = reader.GetInt32("id_prod"),
                        Nome = DAOhelper.GetString(reader, "nome_prod"),
                        Tipo_produto = DAOhelper.GetString(reader, "tipo_prod"),
                        Classificação = DAOhelper.GetString(reader, "classificacao_prod"),
                        Valor_unitario = DAOhelper.GetDouble(reader, "valor_prod"),
                        Cor = DAOhelper.GetString(reader, "cor_prod"),
                        Tamanho = DAOhelper.GetString(reader, "tamanho_prod"),
                        Tipo_tecido = DAOhelper.GetString(reader, "tipo_tecido_prod"),
                        Codigo_barras = DAOhelper.GetString(reader, "codigo_barras_prod")


                    }); ;
                }

                return list;


            }
            catch (Exception )
            {
                throw ;
            }
            finally
            {
                conexao.Close();
            }
        }
    }
}