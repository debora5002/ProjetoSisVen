﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoSisVen_Wpf.Models
{
    internal class VendaProduto
    {
        public int Id { get; set; }

        public string? Quantidade { get; set; }

        public double ? Valor { get; set; }

        public double ValorTotal { get; set; }

        public Produto ? Produto { get; set; }

        public Venda ? Venda { get; set; }

    }
}
