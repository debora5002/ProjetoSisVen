﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.Helpers;
using System;
using System.Collections.Generic;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Interfaces;

namespace ProjetoSisVen_Wpf.Models
{
    class fornecedorDAO : IDAO<Fornecedor>
    {
        private static Conexao conexao;

        public fornecedorDAO()
        {
            conexao = new Conexao();
        }

        public void Delete(Fornecedor t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "DELETE FROM fornecedor WHERE id_for = @id";

                query.Parameters.AddWithValue("@id", t.Id);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexao.Close();
            }
        }

        public Fornecedor GetById(int id)
        {
             try
             {
                var query = conexao.Query();
                query.CommandText = "SELECT * FROM fornecedor WHERE id_for = @codigo";

                query.Parameters.AddWithValue("@codigo", id);

                var resultado = query.ExecuteReader();

                var fornecedor = new Fornecedor();

                while (resultado.Read())
                {
                    fornecedor.Id = resultado.GetInt32("id_for");
                    fornecedor.Nome = DAOhelper.GetString(resultado, "nome_for");
                    fornecedor.NomeFantasia = DAOhelper.GetString(resultado, "nome_fantasia_for");
                    fornecedor.RazaoSocial = DAOhelper.GetString(resultado, "razao_social_for");
                    fornecedor.Email = DAOhelper.GetString(resultado, "email_for");
                    fornecedor.Contato = DAOhelper.GetString(resultado, "contato_for");
                    fornecedor.Cnpj = DAOhelper.GetString(resultado, "cnpj_for");
                }

                return fornecedor;

             } catch (Exception ex)
             {
                throw ex;
             }
        }

        public void Insert(Fornecedor t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "INSERT INTO fornecedor (nome_for, nome_fantasia_for, razao_social_for, email_for, contato_for, cnpj_for) " +
                    "VALUES (@nome, @nomefantasia, @razaosocial, @email, @contato, @cnpj)";

                query.Parameters.AddWithValue("@nome", t.Nome);
                query.Parameters.AddWithValue("@nomefantasia", t.NomeFantasia);
                query.Parameters.AddWithValue("@razaosocial", t.RazaoSocial);
                query.Parameters.AddWithValue("@email", t.Email);
                query.Parameters.AddWithValue("@contato", t.Contato);
                query.Parameters.AddWithValue("@cnpj", t.Cnpj);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Erro ao realizar o cadastro!");

            }
            catch (Exception )
            {
                throw ;
            }
            finally
            {
                conexao.Close();
            }
        }

        public List<Fornecedor> List()
        {
            try
                {
                List<Fornecedor> list = new List<Fornecedor>();

                var query = conexao.Query();
                query.CommandText = "select * from fornecedor";


                MySqlDataReader reader = query.ExecuteReader();

                while (reader.Read())
                {
                    list.Add(new Fornecedor()
                    {
                        Id = reader.GetInt32("id_for") ,
                        Nome = DAOhelper.GetString(reader, "nome_for"),
                        NomeFantasia = DAOhelper.GetString(reader , "nome_fantasia_for") ,
                        RazaoSocial = DAOhelper.GetString(reader , "razao_social_for") ,
                        Email = DAOhelper.GetString(reader , "email_for") ,
                        Contato = DAOhelper.GetString(reader , "contato_for") ,
                        Cnpj = DAOhelper.GetString(reader , "cnpj_for")
                    }); 
                }   

                return list;

            }
            catch (Exception )
            { 
                throw ;
            }
            finally
            {
                conexao.Close();
               
            }
        }

        public void Update(Fornecedor t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "UPDATE fornecedor SET nome_for = @nome, nome_fantasia_for = @nomefantasia, razao_social_for = @razaosocial, " +
                    "email_for = @email, contato_for = @contato, cnpj_for = @cnpj WHERE id_for = @codigo";

                query.Parameters.AddWithValue("@nome", t.Nome);
                query.Parameters.AddWithValue("@nomefantasia", t.NomeFantasia);
                query.Parameters.AddWithValue("@razaosocial", t.RazaoSocial);
                query.Parameters.AddWithValue("@email", t.Email);
                query.Parameters.AddWithValue("@contato", t.Contato);
                query.Parameters.AddWithValue("@cnpj", t.Cnpj);
                query.Parameters.AddWithValue("@codigo", t.Id);

                var resultado = query.ExecuteNonQuery();

                if (resultado == 0)
                {
                    throw new Exception("Registro não atualizado.");
                }

            } catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
