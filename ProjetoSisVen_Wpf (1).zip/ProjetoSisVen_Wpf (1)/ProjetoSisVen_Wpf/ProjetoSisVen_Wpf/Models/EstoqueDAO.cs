﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;

class EstoqueDAO : IDAO<Estoque>
{
    private static Conexao conexao;

    public EstoqueDAO()
    {
        conexao = new Conexao();
    }

    public void Delete(Estoque t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "DELETE FROM estoque WHERE id_est = @id";

            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Insert(Estoque t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "INSERT INTO estoque (nome_est, tipo_est, quantidade_est, id_prod_fk) " +
                "VALUES (@nome, @tipo, @quantidade, @produto)";

            query.Parameters.AddWithValue("@nome", t.Nome);
            query.Parameters.AddWithValue("@tipo", t.Tipo);
            query.Parameters.AddWithValue("@quantidade", t.Quantidade);
            query.Parameters.AddWithValue("@produto", t.Produto.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Erro ao realizar o cadastro!");

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public Estoque GetById(int id)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "SELECT * FROM estoque " + "WHERE id_est = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var estoque = new Estoque();

            while (reader.Read())
            {
                estoque.Id = reader.GetInt32("id_est");
                estoque.Nome = reader.GetString("nome_est");
                estoque.Tipo = reader.GetString("tipo_est");
                estoque.Quantidade = reader.GetInt32("quantidade_est");
                estoque.Produto = new produtoDAO().GetById(reader.GetInt32("id_prod_fk"));
            }

            return estoque;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Query();
        }
    }

    private Estoque ParseReader(MySqlDataReader dtReader)
    {
        throw new NotImplementedException();
    }

    public List<Estoque> List()
    {
        try
        {
            List<Estoque> list = new List<Estoque>();

            var query = conexao.Query();
            query.CommandText = "SELECT * FROM estoque;";

            MySqlDataReader reader = query.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Estoque()
                {
                    Id = reader.GetInt32("id_est"),
                    Nome = DAOhelper.GetString(reader, "nome_est"),
                    Tipo = DAOhelper.GetString(reader, "tipo_est"),
                    Quantidade = Convert.ToInt32(DAOhelper.GetString(reader, "quantidade_est")),
                    Produto = new produtoDAO().GetById(reader.GetInt32("id_prod_fk")),
                });
            }

            return list;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Update(Estoque t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "UPDATE estoque" +
                " SET nome_est = @nome, tipo_est = @tipo, quantidade_est= @quantidade, id_prod_fk = @produto WHERE id_est = @id";

            query.Parameters.AddWithValue("@nome", t.Nome);
            query.Parameters.AddWithValue("@tipo", t.Tipo);
            query.Parameters.AddWithValue("@quantidade", t.Quantidade);
            query.Parameters.AddWithValue("@produto", t.Produto);
            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Atualização do registro não foi realizada.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }
}