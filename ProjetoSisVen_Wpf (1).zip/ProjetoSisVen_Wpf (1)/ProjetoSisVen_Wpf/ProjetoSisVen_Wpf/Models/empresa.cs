﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjetoSisVen_Wpf.Models;
using ProjetoSisVen_Wpf.Interfaces;

namespace ProjetoSisVen_Wpf.Models
{
    class Empresa
    {
        public int Id{ get; set; }

        public string ? Codigo_barras { get; set; }

        public string ? Categoria { get; set;}

        public string ? Tamanho { get; set;}
    }
}
