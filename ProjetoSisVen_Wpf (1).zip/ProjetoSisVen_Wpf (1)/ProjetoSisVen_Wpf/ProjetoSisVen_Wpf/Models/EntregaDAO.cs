﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;

class EntregaDAO : IDAO<Entrega>
{
    private static Conexao conexao;

    public EntregaDAO()
    {
        conexao = new Conexao();
    }

    public void Delete(Entrega t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "DELETE FROM entrega WHERE id_entr = @id";

            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Insert(Entrega t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "INSERT INTO entrega (endereco_entr, telefone_entr, id_cli_fk, id_func_fk) " +
                "VALUES (@endereco, @telefone, @cliente, @funcionario)";

            query.Parameters.AddWithValue("@endereco", t.Endereco);
            query.Parameters.AddWithValue("@telefone", t.Telefone);
            query.Parameters.AddWithValue("@cliente", t.Cliente.Id);
            query.Parameters.AddWithValue("@funcionario", t.Funcionario.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Erro ao realizar o cadastro!");

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            conexao.Close();
        }
    }

    public Entrega GetById(int id)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "SELECT * FROM entrega " + "WHERE id_entr = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var entrega = new Entrega();

            while (reader.Read())
            {
                entrega.Id = reader.GetInt32("id_entr");
                entrega.Endereco = reader.GetString("endereco_entr");
                entrega.Telefone = reader.GetString("telefone_entr");
                entrega.Cliente = new ClienteDAO().GetById(reader.GetInt32("id_cli_fk"));
                entrega.Funcionario = new funcionarioDAO().GetById(reader.GetInt32("id_func_fk"));
            }

            return entrega;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Query();
        }
    }

    private Entrega ParseReader(MySqlDataReader dtReader)
    {
        throw new NotImplementedException();
    }

    public List<Entrega> List()
    {
        try
        {
            List<Entrega> list = new List<Entrega>();

            var query = conexao.Query();
            query.CommandText = "SELECT * FROM entrega;";

            MySqlDataReader reader = query.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Entrega()
                {
                    Id = reader.GetInt32("id_entr"),
                    Endereco = DAOhelper.GetString(reader, "endereco_entr"),
                    Telefone = DAOhelper.GetString(reader, "telefone_entr"),
                    Cliente = new ClienteDAO().GetById(reader.GetInt32("id_cli_fk")),
                    Funcionario = new funcionarioDAO().GetById(reader.GetInt32("id_func_fk")),
                });
            }

            return list;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Update(Entrega t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "UPDATE entrega" +
                " SET endereco_entr = @endereco, telefone_entr = @telefone, id_cli_fk = @cliente, id_func_fk = @funcionario WHERE id_entr = @id";

            query.Parameters.AddWithValue("@endereco", t.Endereco);
            query.Parameters.AddWithValue("@telefone", t.Telefone);
            query.Parameters.AddWithValue("@cliente", t.Cliente);
            query.Parameters.AddWithValue("@funcionario", t.Funcionario);
            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Atualização do registro não foi realizada.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }
}