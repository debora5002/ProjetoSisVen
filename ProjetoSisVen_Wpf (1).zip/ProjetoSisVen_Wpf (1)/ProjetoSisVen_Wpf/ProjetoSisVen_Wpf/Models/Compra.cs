﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoSisVen_Wpf.Models
{
    internal class Compra
    {
        public int Id { get; set; }

        public string ? Nome { get; set; }

        public string ? Codigo_prod { get; set; }

        public int Qtde_produto { get; set; }

        public double Valor_unitario { get; set; }

        public double Valor_total { get; set; }

        public DateTime Data { get; set; }

        public Fornecedor ? Fornecedor { get; set; }

        public Funcionario ? Funcionario { get; set; }

        public Despesa ? Despesa { get; set; }
    }
}
