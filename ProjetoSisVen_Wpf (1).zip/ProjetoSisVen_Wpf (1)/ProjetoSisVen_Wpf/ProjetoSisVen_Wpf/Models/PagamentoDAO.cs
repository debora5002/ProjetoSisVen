﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.Interfaces;
using ProjetoSisVen_Wpf.Models;
using System;
using System.Collections.Generic;

class PagamentoDAO : IDAO<Pagamento>
{
    private static Conexao conexao;

    public PagamentoDAO()
    {
        conexao = new Conexao();
    }

    public void Delete(Pagamento t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "DELETE FROM pagamento WHERE id_pag = @id";

            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Insert(Pagamento t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "INSERT INTO pagamento (tipo_pag, descricao_pag, forma_pagamento_pag, valor_pag, status_pag, data_vencimento_pag, data_pagamento_pag, id_des_fk, id_cai_fk) " +
                "VALUES (@tipo, @descricao, @forma_pagamento, @valor, @status, @data_vencimento, @data_pagamento, @despesa, @caixa)";

            query.Parameters.AddWithValue("@tipo", t.Tipo);
            query.Parameters.AddWithValue("@descricao", t.Descricao);
            query.Parameters.AddWithValue("@forma_pagamento", t.Forma_Pagamento);
            query.Parameters.AddWithValue("@valor", t.Valor);
            query.Parameters.AddWithValue("@status", t.Status);
            query.Parameters.AddWithValue("@data_vencimento", t.DataVencimento);
            query.Parameters.AddWithValue("@data_pagamento", t.DataPagamento);
            query.Parameters.AddWithValue("@despesa", t.Despesa.Id);
            query.Parameters.AddWithValue("@caixa", t.Caixa.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Erro ao realizar o cadastro!");

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public Pagamento GetById(int id)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "SELECT * FROM pagamento " + "WHERE id_pag = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var pagamento = new Pagamento();

            while (reader.Read())
            {
                pagamento.Id = reader.GetInt32("id_pag");
                pagamento.Tipo = reader.GetString("tipo_pag");
                pagamento.Descricao = reader.GetString("descricao_pag");
                pagamento.Forma_Pagamento = reader.GetString("forma_pagamento_pag");
                pagamento.Valor = reader.GetDouble("valor_pag");
                pagamento.Status = reader.GetString("status_pag");
                pagamento.DataVencimento = reader.GetDateTime("data_vencimento_pag");
                pagamento.DataPagamento = reader.GetDateTime("data_pagamento_pag");
                pagamento.Despesa = new DespesaDAO().GetById(reader.GetInt32("id_des_fk"));
                pagamento.Caixa = new CaixaDAO().GetById(reader.GetInt32("id_cai_fk"));
            }

            return pagamento;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Query();
        }
    }

    private Pagamento ParseReader(MySqlDataReader dtReader)
    {
        throw new NotImplementedException();
    }

    public List<Pagamento> List()
    {
        try
        {
            List<Pagamento> list = new List<Pagamento>();

            var query = conexao.Query();
            query.CommandText = "SELECT * FROM pagamento;";

            MySqlDataReader reader = query.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Pagamento()
                {
                    Id = reader.GetInt32("id_pag"),
                    Tipo = DAOhelper.GetString(reader, "tipo_pag"),
                    Descricao = DAOhelper.GetString(reader, "descricao_pag"),
                    Forma_Pagamento = DAOhelper.GetString(reader, "forma_pagamento_pag"),
                    Valor = Convert.ToInt32(DAOhelper.GetString(reader, "valor_pag")),
                    Status = DAOhelper.GetString(reader, "status_pag"),
                    DataVencimento = Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_vencimento_pag")),
                    DataPagamento = Convert.ToDateTime(DAOhelper.GetDateTime(reader, "data_pagamento_pag")),
                    Despesa = new DespesaDAO().GetById(reader.GetInt32("id_des_fk")),
                    Caixa = new CaixaDAO().GetById(reader.GetInt32("id_cai_fk")),
                });
            }

            return list;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            conexao.Close();
        }
    }

    public void Update(Pagamento t)
    {
        try
        {
            var query = conexao.Query();
            query.CommandText = "UPDATE pagamento" +
                " SET tipo_pag = @tipo, descricao_pag = @descricao, forma_pagamento_pag = @forma_pagamento, valor_pag = @valor, status_pag = @status, data_vencimento_pag = @data_vencimento, data_pagamento_pag = @data_pagamento, id_des_fk = @despesa, id_cai_fk = @caixa WHERE id_pag = @id";

            query.Parameters.AddWithValue("@tipo", t.Tipo);
            query.Parameters.AddWithValue("@descricao", t.Descricao);
            query.Parameters.AddWithValue("@forma_pagamento", t.Forma_Pagamento);
            query.Parameters.AddWithValue("@valor", t.Valor);
            query.Parameters.AddWithValue("@status", t.Status);
            query.Parameters.AddWithValue("@data_vencimento", t.DataVencimento);
            query.Parameters.AddWithValue("@data_pagamento", t.DataPagamento);
            query.Parameters.AddWithValue("@despesa", t.Despesa.Id);
            query.Parameters.AddWithValue("@caixa", t.Caixa.Id);
            query.Parameters.AddWithValue("@id", t.Id);

            var result = query.ExecuteNonQuery();

            if (result == 0)
                throw new Exception("Atualização do registro não foi realizada.");

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            conexao.Close();
        }
    }
}