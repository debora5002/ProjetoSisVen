﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoSisVen_Wpf.Models
{
    internal class Estoque
    {
        public int Id { get; set; }

        public string ? Nome { get; set; }

        public string ? Tipo { get; set; }

        public int Quantidade { get; set; }

        public Produto ? Produto { get; set; }
    }
}
