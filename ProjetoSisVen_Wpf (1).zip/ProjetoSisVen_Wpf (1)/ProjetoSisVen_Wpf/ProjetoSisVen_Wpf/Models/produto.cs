﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoSisVen_Wpf.Models
{
    class Produto

    {
        public int Id { get; set; }  
        public string ? Nome {get;set;}

        public string ? Tipo_produto { get;set;}

        public double ? Valor_unitario { get; set; }

        public string ? Tamanho { get; set; }

        public string ? Cor { get; set; }

        public string ? Classificação { get;set;}

        public string ? Tipo_tecido { get; set; }

        public string ?  Codigo_barras { get; set; }

        //public double ? ValorTotal { get; set; }
    }
}
