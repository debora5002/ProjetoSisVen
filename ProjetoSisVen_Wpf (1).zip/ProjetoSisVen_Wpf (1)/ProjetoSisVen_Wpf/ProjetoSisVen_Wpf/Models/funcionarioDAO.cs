﻿using MySql.Data.MySqlClient;
using ProjetoSisVen_Wpf.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjetoSisVen_Wpf.Helpers;
using ProjetoSisVen_Wpf.database;
using ProjetoSisVen_Wpf.Models;

namespace ProjetoSisVen_Wpf.Models
{
    class funcionarioDAO : IDAO<Funcionario>
    {
        private static Conexao conexao;

        public funcionarioDAO()
        {
            conexao = new Conexao();
        }
        public void Delete(Funcionario t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "DELETE FROM funcionario WHERE id_func = @id";

                query.Parameters.AddWithValue("@id", t.Id);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Registro não removido da base de dados. Verifique e tente novamente.");

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexao.Close();
            }
        }

        public Funcionario GetById(int id)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "SELECT * FROM funcionario "  + "WHERE id_func = @id";

                query.Parameters.AddWithValue("@id", id);

                MySqlDataReader reader = query.ExecuteReader();

                if (!reader.HasRows)
                    throw new Exception("Nenhum registro foi encontrado!");

                var funcionario = new Funcionario();

                while (reader.Read())
                {
                    funcionario.Id = reader.GetInt32("id_func");
                    funcionario.Nome = DAOhelper.GetString(reader, "nome_func");
                    funcionario.Telefone = DAOhelper.GetString(reader, "telefone_func");
                    funcionario.Cpf = DAOhelper.GetString(reader, "cpf_func");
                    funcionario.Rg = DAOhelper.GetString(reader, "rg_func");
                    funcionario.Endereco = DAOhelper.GetString(reader, "endereco_func");
                    funcionario.Curriculo = DAOhelper.GetString(reader, "curriculo_func");
                    funcionario.Cargo = DAOhelper.GetString(reader, "cargo_func");
                    funcionario.Salario = DAOhelper.GetDouble(reader, "salario_func");
                }

                return funcionario;
            }
            catch(Exception e)
            {
                throw e;
            }
        }

        public void Insert(Funcionario t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "INSERT INTO funcionario (nome_func, telefone_func, cpf_func, rg_func, endereco_func, curriculo_func, cargo_func, salario_func) " +
                    "VALUES (@nome, @telefone, @cpf, @rg, @endereco, @curriculo, @cargo, @salario)";

                query.Parameters.AddWithValue("@nome", t.Nome);
                query.Parameters.AddWithValue("@telefone", t.Telefone);
                query.Parameters.AddWithValue("@cpf", t.Cpf);
                query.Parameters.AddWithValue("@rg", t.Rg);
                query.Parameters.AddWithValue("@endereco", t.Endereco);
                query.Parameters.AddWithValue("@curriculo", t.Curriculo);
                query.Parameters.AddWithValue("@cargo", t.Cargo);
                query.Parameters.AddWithValue("@salario", t.Salario);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Erro ao realizar o cadastro!");

            }
            catch (Exception )
            {
                throw ;
            }
            finally
            {
                conexao.Close();
            }
        }

        public List<Funcionario> List()
        {

            try
            {
                List<Funcionario> list = new List<Funcionario>();

                var query = conexao.Query();
                query.CommandText = "SELECT * FROM funcionario";

                MySqlDataReader reader = query.ExecuteReader();

                while (reader.Read())
                {
                    list.Add(new Funcionario()
                    {
                        Id = reader.GetInt32("id_func"),
                        Nome = DAOhelper.GetString(reader, "nome_func"),
                        Telefone = DAOhelper.GetString(reader, "telefone_func"),
                        Cpf = DAOhelper.GetString(reader, "cpf_func"),
                        Rg = DAOhelper.GetString(reader, "rg_func"),
                        Endereco = DAOhelper.GetString(reader, "endereco_func"),
                        Curriculo = DAOhelper.GetString(reader, "curriculo_func"),
                        Cargo = DAOhelper.GetString(reader, "cargo_func"),
                        Salario = DAOhelper.GetDouble(reader, "salario_func"),                                           
                    });
                }

                return list;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void Update(Funcionario t)
        {
            try
            {
                var query = conexao.Query();
                query.CommandText = "UPDATE funcionario SET nome_func = @nome, telefone_func = @telefone, " +
                    "cpf_func = @cpf, rg_func = @rg, endereco_func = @endereco, " +
                    "curriculo_func = @curriculo, cargo_func = @cargo, salario_func = @salario WHERE id_func = @id";

                query.Parameters.AddWithValue("@nome", t.Nome);
                query.Parameters.AddWithValue("@telefone", t.Telefone);
                query.Parameters.AddWithValue("@cpf", t.Cpf);
                query.Parameters.AddWithValue("@rg", t.Rg);
                query.Parameters.AddWithValue("@endereco", t.Endereco);
                query.Parameters.AddWithValue("@curriculo", t.Curriculo);
                query.Parameters.AddWithValue("@cargo", t.Cargo);
                query.Parameters.AddWithValue("@salario", t.Salario);
                query.Parameters.AddWithValue("@id", t.Id);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Atualização do registro não foi realizada.");

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexao.Close();
            }
        }
    }
}
